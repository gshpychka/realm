from __future__ import annotations

import copy
import ftplib
import json
import math
import os
import re
import threading
import shutil
import time

from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from dateutil import parser, tz
from pathlib import Path
from zipfile import ZipFile
from typing import List, Union
import xml.etree.ElementTree as ElementTree
from PIL import Image
import asyncio

from .utils import (
    search,
    fan_percentage,
    fan_percentage_to_gcode,
    get_current_stage,
    get_filament_name,
    get_ip_address_from_int,
    get_printer_type,
    get_speed_name,
    get_hw_version,
    get_sw_version,
    compare_version,
    get_end_time,
    get_HMS_error_text,
    get_print_error_text,
    get_HMS_severity,
    get_HMS_module,
    set_temperature_to_gcode,
    get_upgrade_url,
    upgrade_template,
    get_wiki_url_for_hms_error,
    ams_tray_spool_loaded,
)
from .const import (
    LOGGER,
    Features,
    FansEnum,
    Home_Flag_Values,
    Stat_Flag_Values,
    Printers,
    SPEED_PROFILE,
    GCODE_STATE_OPTIONS,
    PRINT_TYPE_OPTIONS,
    AIRDUCT_MODES,
    TempEnum, Print_Fun_Values,
    UNKNOWN_TRAY_LABEL,
)
from .commands import (
    CHAMBER_LIGHT_ON,
    CHAMBER_LIGHT_OFF,
    CHAMBER_LIGHT_2_ON,
    CHAMBER_LIGHT_2_OFF,
    PROMPT_SOUND_ENABLE,
    PROMPT_SOUND_DISABLE,
    AIRDUCT_SET_MODE_TEMPLATE,
    SPEED_PROFILE_TEMPLATE,
    BUZZER_SET_SILENT,
    BUZZER_SET_ALARM,
    BUZZER_SET_BEEPING,
    HEATBED_LIGHT_ON,
    HEATBED_LIGHT_OFF,
)
from .media_sources import (
    Ftps990MediaSource,
    RemoteMediaError,
    RemoteMediaFile,
    RemoteMediaSource,
    ProgressCallback,
    Tcp6000MediaSource,
    canonical_storage,
    dedupe_remote_files,
    sort_newest_first,
    source_priority,
    storage_cache_segment,
)

class Device:
    def __init__(self, client):
        self._client = client
        self.temperature = Temperature(client = client)
        self.lights = Lights(client = client)
        self.info = Info(client = client)
        self.upgrade = Upgrade(client = client)
        self.print_job = PrintJob(client = client)
        self.fans = Fans(client = client)
        self.speed = Speed(client = client)
        self.stage = StageAction()
        self.ams = AMSList(client = client)
        self.external_spool = [ ExternalSpool(client = client, index = 0), ExternalSpool(client = client, index = 1) ]
        self.hms = HMSList(client = client)
        self.print_error = PrintError(client = client)
        self.camera = Camera(client = client)
        self.home_flag = HomeFlag(client=client)
        self.extruder = Extruder(client=client)
        self.extruder_tool = ExtruderTool(client=client)
        self.hotend_rack = HotendRack(client=client)
        self.push_all_data = None
        self.get_version_data = None
        self.chamber_image = ChamberImage(client = client)
        self.cover_image = CoverImage(client = client)
        self.pick_image = PickImage(client = client)
        self.print_fun = PrintFun(client = client)

    def print_update(self, data) -> bool:
        send_event = False
        send_event = send_event | self.info.print_update(data = data)
        send_event = send_event | self.upgrade.print_update(data = data)
        send_event = send_event | self.print_job.print_update(data = data)
        send_event = send_event | self.lights.print_update(data = data)
        send_event = send_event | self.fans.print_update(data = data)
        send_event = send_event | self.speed.print_update(data = data)
        send_event = send_event | self.stage.print_update(data = data)
        send_event = send_event | self.extruder.print_update(data = data) # Must be before the AMS and external spools and temperature
        send_event = send_event | self.temperature.print_update(data = data)
        send_event = send_event | self.ams.print_update(data = data)
        send_event = send_event | self.external_spool[0].print_update(data = data)
        send_event = send_event | self.external_spool[1].print_update(data = data)
        send_event = send_event | self.hms.print_update(data = data)
        send_event = send_event | self.print_error.print_update(data = data)
        send_event = send_event | self.camera.print_update(data = data)
        send_event = send_event | self.home_flag.print_update(data = data)
        send_event = send_event | self.print_fun.print_update(data = data)
        send_event = send_event | self.extruder_tool.print_update(data = data)
        send_event = send_event | self.hotend_rack.print_update(data = data)

        if data.get("command") == "push_status":
            if data.get("msg", 0) == 0:
                send_ready_event = self.get_version_data is not None and self.push_all_data is None
                if self.push_all_data is None:
                    LOGGER.debug("Reached first push of all data.")
                self.push_all_data = data
                if send_ready_event:
                    self._client.callback("event_printer_ready")

        # Only notify Home Assistant when something actually changed. The printer pushes
        # status roughly once a second; without this gate every push forces all entities
        # to recompute and rewrite their state.
        if send_event:
            self._client.callback("event_printer_data_update")

    @property
    def has_full_printer_data(self):
        return (self.push_all_data != None) and (self.get_version_data != None)

    def info_update(self, data):
        had_full_printer_data = self.has_full_printer_data
        self.info.info_update(data = data)
        self.home_flag.info_update(data = data)
        ams_info_changed = self.ams.info_update(data = data)

        if data.get("command") == "get_version":
            send_ready_event = self.get_version_data is None and self.push_all_data is not None
            if self.get_version_data is None:
                LOGGER.debug("Reached first push of version data.")
            self.get_version_data = data
            if send_ready_event:
                self._client.callback("event_printer_ready")
            elif had_full_printer_data and ams_info_changed:
                # A later get_version response can fill in AMS identity metadata that was
                # missing during initial startup. Re-run entity setup so placeholder AMS
                # entries are replaced with entities using the real serial/model.
                self._client.callback("event_printer_ready")


    def observe_system_command(self, data):
        if data.get("command") == "ledctrl" and data.get("led_node") == "heatbed_light":
            self.lights.observe_system_command(data)

    def supports_feature(self, feature):
        a1_printers = {Printers.A1, Printers.A1MINI}
        a2_printers = {Printers.A2L}
        h2_printers = {Printers.H2C, Printers.H2D, Printers.H2DPRO, Printers.H2S}
        p1_printers = {Printers.P1P, Printers.P1S}
        p2_printers = {Printers.P2S}
        x1_printer  = {Printers.X1, Printers.X1C}
        x1e_printer = {Printers.X1E} # Firmware versioning is independent of X1/X1C.
        x2_printers = {Printers.X2D}
        dual_nozzle_printers = {Printers.H2C, Printers.H2D, Printers.H2DPRO, Printers.X2D}
        model = self.info.device_type

        # First check known early feature check scenarios. These are features that can be checked as part of
        # processing the mqtt payload and so may be called before full initialization is complete as it processes
        # the very first payload.
        if feature == Features.CAMERA_RTSP:
            return model in (h2_printers | p2_printers | x1_printer | x1e_printer | x2_printers)
        elif feature == Features.CAMERA_IMAGE:
            return model in (a1_printers | a2_printers | p1_printers)
        elif feature == Features.SUPPORTS_EARLY_FTP_DOWNLOAD:
            return model in (a1_printers | a2_printers | p1_printers)

        # Now check that we have a version. All tests after this are expected to only be called after the
        # first full set of data from the printer has been received and so version will be available.
        if self.info.sw_ver == "unknown":
            LOGGER.error(f"supports_feature queried for {feature} before printer firmware version is known.")
            return False

        # All following features should only be every checked after full initialization data is available.
        if feature == Features.AUX_FAN:
            return model not in (a1_printers | a2_printers)
        elif feature == Features.CHAMBER_FAN:
            # The P1P may not have a fan but we don't have a perfectly reliable way to detect that. The p1s upgrade
            # flag would largely be good though but not accessible here.
            return model not in (a1_printers | a2_printers)
        elif feature == Features.CHAMBER_TEMPERATURE:
            return model in (h2_printers | p2_printers | x1_printer | x1e_printer | x2_printers)
        elif feature == Features.AMS:
            return len(self.ams.data) != 0
        elif feature == Features.K_VALUE:
            return model in (a1_printers | a2_printers | p1_printers)
        elif feature == Features.AMS_TEMPERATURE:
            if model in a1_printers:
                return self.supports_sw_version("01.06.10.33")
            if model in p1_printers:
                return self.supports_sw_version("01.07.50.18")
            return True
        elif feature == Features.AIRDUCT_MODE:
            # Airduct mode (Filter/Heating and Cooling) is present on P2S and H2 series
            return model in (h2_printers | p2_printers | x2_printers)
        elif feature == Features.HYBRID_MODE_BLOCKS_CONTROL:
            if model in p1_printers:
                # Not sure what the first version that did this was. At least this - could be earlier.
                return self.supports_sw_version("01.07.00.00")
            # Only the P1 firmware did this as far as I know. Not the A1.
            return False
        elif feature == Features.DOOR_SENSOR:
            if model in (h2_printers | p2_printers | x2_printers):
                return True
            if model in x1e_printer:
                return self.supports_sw_version("01.01.02.00")
            if model in x1_printer:
                return self.supports_sw_version("01.07.00.00")
            return False
        elif feature == Features.AMS_READ_RFID_COMMAND:
            if model in a1_printers:
                return self.supports_sw_version("01.06.00.00")
            if model in p1_printers:
                return self.supports_sw_version("01.08.01.00")
            if model in x1e_printer:
                # Do not know if the X1E supports this, or at what version support was added.
                return False
            if model in x1_printer:
                return self.supports_sw_version("01.09.00.00")
            return True
        elif feature == Features.AMS_FILAMENT_REMAINING:
            if model in a1_printers:
                # Technically this is not the AMS Lite but that's currently tied to only these printer types.
                # This needs fixing now the A1 printers support the other AMS models.
                return self.supports_sw_version("01.06.10.33")
            return True
        elif feature == Features.PROMPT_SOUND:
            if model in (a1_printers | a2_printers | h2_printers | p2_printers | x2_printers):
                return not self.print_fun.mqtt_signature_required
            return False
        elif feature == Features.AMS_SWITCH_COMMAND:
            if model in p1_printers:
                return self.supports_sw_version("01.02.99.10")
            if model in x1e_printer:
                # Do not know if the X1E supports this, or at what version support was added.
                return False
            if model in x1_printer:
                return self.supports_sw_version("01.05.06.01")
            return True
        elif feature == Features.AMS_HUMIDITY:
            if model in a1_printers:
                return self.supports_sw_version("01.06.10.33")
            if model in p1_printers:
                return self.supports_sw_version("01.07.50.18")
            if model in x1e_printer:
                # Do not know if the X1E supports this, or at what version support was added.
                return False
            if model in x1_printer:
                return self.supports_sw_version("01.08.50.18")
            return True
        elif feature == Features.AMS_DRYING:
            if model in a1_printers:
                return self.supports_sw_version("01.06.10.33")
            if model in p1_printers:
                return self.supports_sw_version("01.07.50.18")
            if model in x1e_printer:
                # Do not know if the X1E supports this, or at what version support was added.
                return False
            if model in x1_printer:
                return self.supports_sw_version("01.08.50.18")
            return True
        elif feature == Features.AMS_DRYING_SETTINGS:
            if model in p2_printers:
                return self.supports_sw_version("01.01.50.40")
            if model == Printers.H2C:
                return self.supports_sw_version("01.01.50.00")
            return False
        elif feature == Features.CHAMBER_LIGHT_2:
            return model in (h2_printers | x2_printers)
        elif feature == Features.DUAL_NOZZLES:
            return model in dual_nozzle_printers
        elif feature == Features.EXTRUDER_TOOL:
            return model in (h2_printers | x2_printers)
        elif feature == Features.MQTT_ENCRYPTION_FIRMWARE:
            if model in a1_printers:
                return self.supports_sw_version("01.05.00.00")
            if model in (Printers.H2D, Printers.H2DPRO):
                return self.supports_sw_version("01.01.00.00")
            if model in p1_printers:
                return self.supports_sw_version("01.08.02.00")
            if model in x1e_printer:
                # Do not know if the X1E requires this, or at what version support was added.
                return False
            if model in x1_printer:
                return self.supports_sw_version("01.08.50.32")
            return True
        elif feature == Features.FIRE_ALARM_BUZZER:
            return model in h2_printers
        elif feature == Features.HEATBED_LIGHT:
            return model in h2_printers
        elif feature == Features.SECONDARY_AUX_FAN:
            return model in (p2_printers | x2_printers)
        elif feature == Features.HOTEND_RACK:
            return model == Printers.H2C and len(self.hotend_rack.hotends) > 0
        elif feature == Features.ACTIVE_CHAMBER_HEATER:
            return model in (x1e_printer | h2_printers | x2_printers)
        return False
    
    def supports_sw_version(self, version: str) -> bool:
        if compare_version(self.info.sw_ver, "99.0.0.0") >= 0:
            # This is an X1+ firmware version. Treat it as 01.08.02.00.
            return compare_version("01.08.02.00", version) >= 0
        return compare_version(self.info.sw_ver, version) >= 0
    
    @property
    def is_core_xy(self) -> bool:
        return (self.info.device_type != Printers.A1 and
                self.info.device_type != Printers.A1MINI and
                self.info.device_type != Printers.A2L)

@dataclass
class Lights:
    """Return all light related info"""
    chamber_light: str
    chamber_light2: str
    chamber_light_override: str
    chamber_light2_override: str
    heatbed_light: str
    work_light: str

    def __init__(self, client):
        self._client = client
        self.chamber_light = "unknown"
        self.chamber_light2 = "unknown"
        self.heatbed_light = "unknown"
        self.work_light = "unknown"
        self.chamber_light_override = ""
        self.chamber_light2_override = ""

    @property
    def is_chamber_light_on(self):
        return self.chamber_light == "on" or self.chamber_light2 == "on"

    @property
    def is_heatbed_light_on(self) -> bool | None:
        if self.heatbed_light == "unknown":
            return None
        return self.heatbed_light == "on"

    def print_update(self, data) -> bool:
        old_data = f"{self.__dict__}"

        # "lights_report": [
        #     {
        #         "node": "chamber_light",
        #         "mode": "on"
        #     },
        #     {
        #         "node": "work_light",  # X1 only
        #         "mode": "flashing"
        #     }
        # ],

        chamber_light = \
            search(data.get("lights_report", []), lambda x: x.get('node', "") == "chamber_light",
                   {"mode": self.chamber_light}).get("mode")
        if self.chamber_light_override != "":
            if self.chamber_light_override == chamber_light:
                self.chamber_light_override = ""
        else:
            self.chamber_light = chamber_light

        chamber_light2 = \
            search(data.get("lights_report", []), lambda x: x.get('node', "") == "chamber_light2",
                   {"mode": self.chamber_light2}).get("mode")
        if self.chamber_light2_override != "":
            if self.chamber_light2_override == chamber_light2:
                self.chamber_light2_override = ""
        else:
            self.chamber_light2 = chamber_light2

        self.work_light = \
            search(data.get("lights_report", []), lambda x: x.get('node', "") == "work_light",
                   {"mode": self.work_light}).get("mode")

        # Currently, the status of headbed light is not available (even switching it using printer UI shows an
        #   error in MQTT: "did not find the valid led: heatbed_light"). Therefore, it is initially in an unknown state.

        return (old_data != f"{self.__dict__}")

    def observe_system_command(self, data):
        # State can be inferred from system->command = ledctrl, but the initial state is still not known.
        # Even printer UI causes such a message to be sent as the "command execution result".
        if data.get("led_node") == "heatbed_light":
            self.heatbed_light = data.get("led_mode")
        # Should be replaced with proper reading in print_update once fixed in the actual firmware

    def TurnChamberLightOn(self):
        self.chamber_light = "on"
        self.chamber_light_override = "on"
        self._client.callback("event_light_update")
        self._client.publish(CHAMBER_LIGHT_ON)
        if self._client._device.supports_feature(Features.CHAMBER_LIGHT_2):
            self._client.publish(CHAMBER_LIGHT_2_ON)

    def TurnChamberLightOff(self):
        self.chamber_light = "off"
        self.chamber_light_override = "off"
        self._client.callback("event_light_update")
        self._client.publish(CHAMBER_LIGHT_OFF)
        if self._client._device.supports_feature(Features.CHAMBER_LIGHT_2):
            self._client.publish(CHAMBER_LIGHT_2_OFF)

    def TurnHeatbedLightOn(self):
        self.heatbed_light = "on"
        self._client.callback("event_light_update")
        self._client.publish(HEATBED_LIGHT_ON)

    def TurnHeatbedLightOff(self):
        self.heatbed_light = "off"
        self._client.callback("event_light_update")
        self._client.publish(HEATBED_LIGHT_OFF)


@dataclass
class Camera:
    """Return camera related info"""
    recording: str
    resolution: str
    rtsp_url: str
    timelapse: str
    _fired_camera_disabled_event: bool

    def __init__(self, client):
        self._client = client
        self.recording = ''
        self.resolution = ''
        self.rtsp_url = None
        self.timelapse = ''
        self._fired_camera_disabled_event = False

    def print_update(self, data) -> bool:
        old_data = f"{self.__dict__}"

        # "ipcam": {
        #   "ipcam_dev": "1",
        #   "ipcam_record": "enable",
        #   "mode_bits": 2,
        #   "resolution": "1080p",
        #   "rtsp_url": "rtsps://192.168.1.64/streaming/live/1",
        #   "timelapse": "disable",
        #   "tutk_server": "disable"
        # }

        self.timelapse = (data.get("ipcam") or {}).get("timelapse", self.timelapse)
        self.recording = (data.get("ipcam") or {}).get("ipcam_record", self.recording)
        self.resolution = (data.get("ipcam") or {}).get("resolution", self.resolution)
        self.rtsp_url = (data.get("ipcam") or {}).get("rtsp_url", self.rtsp_url)
        if self._client._enable_camera:
            if self.rtsp_url == "disable":
                if not self._fired_camera_disabled_event:
                    self._fired_camera_disabled_event = True
                    self._client.callback("event_printer_live_view_disabled")
        
        return (old_data != f"{self.__dict__}")

@dataclass
class Temperature:
    """Return all temperature related info"""
    bed_temp: int
    target_bed_temp: int
    chamber_temp: int
    nozzle_temps: dict
    target_nozzle_temps: dict

    def __init__(self, client):
        self._client = client
        self.bed_temp = 0
        self.target_bed_temp = 0
        self.chamber_temp = 0
        self.target_chamber_temp = 0
        self.nozzle_temps = { 0: 0, 1: 0, 15: 0}
        self.target_nozzle_temps = { 0:0, 1: 0, 15: 0}

    @property
    def active_nozzle_temperature(self):
        active_nozzle = self._client._device.extruder.active_nozzle_index
        return self.nozzle_temps[active_nozzle]

    @property
    def active_nozzle_target_temperature(self):
        active_nozzle = self._client._device.extruder.active_nozzle_index
        return self.target_nozzle_temps[active_nozzle]

    @property
    def left_nozzle_temperature(self):
        return self.nozzle_temps[1]

    @property
    def left_nozzle_target_temperature(self):
        return self.target_nozzle_temps[1]

    @property
    def right_nozzle_temperature(self):
        return self.nozzle_temps[0]

    @property
    def right_nozzle_target_temperature(self):
        return self.target_nozzle_temps[0]

    def print_update(self, data) -> bool:
        old_data = f"{self.__dict__}"

        # New firmware puts bed temperature in two different places. Low word is current value. High word is the target.
        # "device": {
        #     "bed": {
        #       "info": {
        #         "temp": 6553700
        #       },
        #       "state": 2
        #     },
        #     "bed_temp": 6553700,
            
        bed_temp = data.get("device", {}).get("bed", {}).get("info", {}).get("temp", None)
        if bed_temp is not None:
            self.bed_temp = bed_temp & 0xFFFF
            self.target_bed_temp = (bed_temp >> 16) & 0xFFFF
        else:
            self.bed_temp = round(data.get("bed_temper", self.bed_temp))
            # Bambu Studio floors the value so match it.
            self.target_bed_temp = math.floor(data.get("bed_target_temper", self.target_bed_temp))

        # New firmware puts the chamber temperature in a different place.
        # "device": {
        #     "ctc": {
        #       "info": {
        #         "temp": 43
        #       },
        #       "state": 0
        #     },
        chamber_temp = data.get("device", {}).get("ctc", {}).get("info", {}).get("temp", None)
        if chamber_temp is not None:
            self.chamber_temp = chamber_temp & 0xFFFF
            self.target_chamber_temp = (chamber_temp >> 16) & 0xFFFF
        else:
            self.chamber_temp = round(data.get("chamber_temper", self.chamber_temp))

        # H2D has two nozzles in the extruder data block.
        # "extruder": {
        #   "info": [
        #     {
        #       ...
        #       "id": 0,
        #       "snow": 259,    // bottom 4 bits is tray, remainder is ams index - not sure about ams HT 128+ though
        #       "temp": 14418140 // low word is current, high word is target
        #     },
        #     {
        #       ...
        #       "id": 1,
        #       "snow": 3,      // bottom 4 bits is tray, remainder is ams index - not sure about ams HT 128+ though
        #       "temp": 5767327  // low word is current, high word is target
        #     }
        #   ],
        #   "state": 2 // low 4 bits is count of extruders; active extruder is next 4 bits
        # },
        extruder_data = data.get("device", {}).get("extruder", {}).get("info")
        if extruder_data is not None:
            for entry in extruder_data:
                if entry.get("id") in (0, 1):
                    if "temp" in entry:
                        self.nozzle_temps[entry["id"]] = entry["temp"] & 0xFFFF
                        self.target_nozzle_temps[entry["id"]] = (entry["temp"] >> 16) & 0xFFFF
        else:
            self.nozzle_temps[0] = round(data.get("nozzle_temper", self.nozzle_temps[0]))
            self.target_nozzle_temps[0] = round(data.get("nozzle_target_temper", self.target_nozzle_temps[0]))

        return (old_data != f"{self.__dict__}")

    def set_target_temp(self, temp: TempEnum, temperature: int):
        command = set_temperature_to_gcode(temp, temperature, self._client._device.info.device_type)

        # if type == TempEnum.HEATBED:
        #     self.bed_temp = temperature
        # elif type == TempEnum.NOZZLE:
        #     self.nozzle_temp = temperature

        LOGGER.debug(command)
        self._client.publish(command)

        self._client.callback("event_printer_data_update")


@dataclass
class Fans:
    """Return all fan related info"""
    _aux_fan_speed_percentage: int
    _aux_fan_speed: int
    _aux_fan_speed_override: int
    _aux_fan_speed_override_time: datetime
    _chamber_fan_speed_percentage: int
    _chamber_fan_speed: int
    _chamber_fan_speed_override: int
    _chamber_fan_speed_override_time: datetime
    _cooling_fan_speed_percentage: int
    _cooling_fan_speed: int
    _cooling_fan_speed_override: int
    _cooling_fan_speed_override_time: datetime
    _heatbreak_fan_speed_percentage: int
    _heatbreak_fan_speed: int
    _secondary_aux_fan_speed_percentage: int
    _secondary_aux_fan_speed: int
    _secondary_aux_fan_speed_override: int
    _secondary_aux_fan_speed_override_time: datetime

    def __init__(self, client):
        self._client = client
        self._aux_fan_speed_percentage = 0
        self._aux_fan_speed = 0
        self._aux_fan_speed_override = 0
        self._aux_fan_speed_override_time = None
        self._chamber_fan_speed_percentage = 0
        self._chamber_fan_speed = 0
        self._chamber_fan_speed_override = 0
        self._chamber_fan_speed_override_time = None
        self._cooling_fan_speed_percentage = 0
        self._cooling_fan_speed = 0
        self._cooling_fan_speed_override = 0
        self._cooling_fan_speed_override_time = None
        self._heatbreak_fan_speed_percentage = 0
        self._heatbreak_fan_speed = 0
        self._secondary_aux_fan_speed_percentage = 0
        self._secondary_aux_fan_speed = 0
        self._secondary_aux_fan_speed_override = 0
        self._secondary_aux_fan_speed_override_time = None

    def print_update(self, data) -> bool:
        old_data = f"{self.__dict__}"

        self._aux_fan_speed = data.get("big_fan1_speed", self._aux_fan_speed)
        self._aux_fan_speed_percentage = fan_percentage(self._aux_fan_speed)
        if self._aux_fan_speed_override_time is not None:
            delta = datetime.now() - self._aux_fan_speed_override_time
            if delta.seconds > 5:
                self._aux_fan_speed_override_time = None
        self._chamber_fan_speed = data.get("big_fan2_speed", self._chamber_fan_speed)
        self._chamber_fan_speed_percentage = fan_percentage(self._chamber_fan_speed)
        if self._chamber_fan_speed_override_time is not None:
            delta = datetime.now() - self._chamber_fan_speed_override_time
            if delta.seconds > 5:
                self._chamber_fan_speed_override_time = None
        self._cooling_fan_speed = data.get("cooling_fan_speed", self._cooling_fan_speed)
        self._cooling_fan_speed_percentage = fan_percentage(self._cooling_fan_speed)
        if self._cooling_fan_speed_override_time is not None:
            delta = datetime.now() - self._cooling_fan_speed_override_time
            if delta.seconds > 5:
                self._cooling_fan_speed_override_time = None
        self._heatbreak_fan_speed = data.get("heatbreak_fan_speed", self._heatbreak_fan_speed)
        self._heatbreak_fan_speed_percentage = fan_percentage(self._heatbreak_fan_speed)
        airduct_parts = data.get("device", {}).get("airduct", {}).get("parts")
        if airduct_parts:
            fan_part = next((item for item in airduct_parts if item.get("id") == 160), None)
            if fan_part is not None:
                # airduct.parts[].state is already a percentage (0-100); write
                # it directly into the percentage field. fan_percentage()
                # expects a raw 0-15 PWM value and would multiply by ~6.67.
                self._secondary_aux_fan_speed_percentage = fan_part.get(
                    "state", self._secondary_aux_fan_speed_percentage
                )
        if self._secondary_aux_fan_speed_override_time is not None:
            delta = datetime.now() - self._secondary_aux_fan_speed_override_time
            if delta.seconds > 5:
                self._secondary_aux_fan_speed_override_time = None

        return (old_data != f"{self.__dict__}")

    def set_fan_speed(self, fan: FansEnum, percentage: int) -> bool:
        """Set fan speed"""
        percentage = round(percentage / 10) * 10
        command = fan_percentage_to_gcode(fan, percentage)

        # Do not report a local override when the broker rejected the publish.
        if not self._client.publish(command):
            return False

        if fan == FansEnum.PART_COOLING:
            self._cooling_fan_speed_override = percentage
            self._cooling_fan_speed_override_time = datetime.now()
        elif fan == FansEnum.AUXILIARY:
            self._aux_fan_speed_override = percentage
            self._aux_fan_speed_override_time = datetime.now()
        elif fan == FansEnum.CHAMBER:
            self._chamber_fan_speed_override = percentage
            self._chamber_fan_speed_override_time = datetime.now()
        elif fan == FansEnum.SECONDARY_AUXILIARY:
            self._secondary_aux_fan_speed_override = percentage
            self._secondary_aux_fan_speed_override_time = datetime.now()

        self._client.callback("event_printer_data_update")
        return True

    def get_fan_speed(self, fan: FansEnum) -> int:
        if fan == FansEnum.PART_COOLING:
            if self._cooling_fan_speed_override_time is not None:
                return self._cooling_fan_speed_override
            else:
                return self._cooling_fan_speed_percentage
        elif fan == FansEnum.AUXILIARY:
            if self._aux_fan_speed_override_time is not None:
                return self._aux_fan_speed_override
            else:
                return self._aux_fan_speed_percentage
        elif fan == FansEnum.CHAMBER:
            if self._chamber_fan_speed_override_time is not None:
                return self._chamber_fan_speed_override
            else:
                return self._chamber_fan_speed_percentage
        elif fan == FansEnum.HEATBREAK:
            return self._heatbreak_fan_speed_percentage
        elif fan == FansEnum.SECONDARY_AUXILIARY:
            if self._secondary_aux_fan_speed_override_time is not None:
                return self._secondary_aux_fan_speed_override
            return self._secondary_aux_fan_speed_percentage

@dataclass
class Upgrade:
    """ Upgrade class """
    printer_name: str
    upgrade_progress: int
    new_version_state: int
    new_ver_list: list
    cur_version: str
    new_version: str

    def __init__(self, client):
        self._client = client
        self.printer_name = None
        self.upgrade_progress = 0
        self.new_version_state = 0
        self.new_ver_list = []
        self.cur_version = None
        self.new_version = None
    
    def release_url(self) -> str:
        """Return the release url"""
        device_mapping = {
            Printers.P1P: "p1",
            Printers.P1S: "p1",
            Printers.A1MINI: "a1-mini",
            Printers.A1: "a1",
            Printers.A2L: "a2",
            Printers.X1C: "x1",
            Printers.X1E: "x1e",
            Printers.X2D: "x2",
        }
        self.printer_name = device_mapping.get(self._client._device.info.device_type)
        if self.printer_name is None:
            return None
        return f"https://bambulab.com/en/support/firmware-download/{self.printer_name}"
    
    def install(self):
        """Install the update"""
        if self.printer_name is None:
            LOGGER.error("Printer name not found for firmware update.")
            return

        url = get_upgrade_url(self.printer_name)
        if url is not None:
            template = upgrade_template(url)
            if template is not None:
                LOGGER.debug(template)
                self._client.publish(template)
                self._client.callback("event_printer_data_update")
                
    def print_update(self, data) -> bool:
        """Update the upgrade state"""
        old_data = f"{self.__dict__}"
        
        # Example payload for P1 printer
        # "upgrade_state": {
        #   "sequence_id": 0,
        #   "progress": "100",
        #   "status": "UPGRADE_SUCCESS",
        #   "consistency_request": false,
        #   "dis_state": 1,
        #   "err_code": 0,
        #   "force_upgrade": false,
        #   "message": "0%, 0B/s",
        #   "module": "ota",
        #   "new_version_state": 1,
        #   "cur_state_code": 0,
        #   "new_ver_list": [
        #     {
        #       "name": "ota",
        #       "cur_ver": "01.06.01.02",
        #       "new_ver": "01.07.00.00",
        #       "cur_release_type": 3,
        #       "new_release_type": 3
        #     }
        #   ]
        # },
        #
        # Example payload for P1 printer with outstanding AMS firmware update:
        # "upgrade_state": {
        #   "sequence_id": 0,
        #   "progress": "100",
        #   "status": "UPGRADE_SUCCESS",
        #   "consistency_request": false,
        #   "dis_state": 1,
        #   "err_code": 0,
        #   "force_upgrade": false,
        #   "message": "0%, 0B/s",
        #   "module": "ota",
        #   "new_version_state": 1,
        #   "cur_state_code": 0,
        #   "idx2": 2118490042,
        #   "new_ver_list": [
        #     {
        #       "name": "ams/0",
        #       "cur_ver": "00.00.06.44",
        #       "new_ver": "00.00.06.49",
        #       "cur_release_type": 0,
        #       "new_release_type": 1
        #      }
        #   ]
        # },
        #
        # Example payload for X1 printer
        # "upgrade_state": {
        #   "ahb_new_version_number": "",
        #   "ams_new_version_number": "",
        #   "consistency_request": false,
        #   "dis_state": 3,
        #   "err_code": 0,
        #   "ext_new_version_number": "",
        #   "force_upgrade": false,
        #   "idx": 4,
        #   "idx1": 3,
        #   "message": "RK1126 start write flash success",
        #   "module": "",
        #   "new_version_state": 1,
        #   "ota_new_version_number": "01.08.02.00",
        #   "progress": "100",
        #   "sequence_id": 0,
        #   "sn": "**REDACTED**",
        #   "status": "UPGRADE_SUCCESS"
        # },
        
        # Cross-validation on the remaining series is required. 
        # Data values ​​for the upgrade_state dictionary
        state = data.get("upgrade_state", None)
        if state is not None:
            try:
                self.upgrade_progress = int(state.get("progress", self.upgrade_progress))
            except ValueError:
                # Prevents unexpected "" strings from being empty.
                self.upgrade_progress = 0
            self.new_version_state = state.get("new_version_state", self.new_version_state)
            self.cur_version = self._client._device.info.sw_ver
            self.new_version = self._client._device.info.sw_ver
            self.new_ver_list = state.get("new_ver_list", self.new_ver_list)
            if self.new_version_state == 1:
                if len(self.new_ver_list) > 0:
                    ota_info = next(filter(
                        lambda x: x["name"] == "ota", self.new_ver_list
                    ), {})
                    if ota_info:
                        self.cur_version = ota_info["cur_ver"]
                        self.new_version = ota_info["new_ver"]
                    if self.upgrade_progress == 100 and state.get("message") == "0%, 0B/s":
                        self.upgrade_progress = 0
                elif state.get("ota_new_version_number", None) != None:
                    self.new_version = state.get("ota_new_version_number")
                    if self.upgrade_progress == 100 and state.get("message") == "RK1126 start write flash success":
                        self.upgrade_progress = 0
                else:
                    LOGGER.error(f"Unable to interpret {state}")
            
        return (old_data != f"{self.__dict__}")


# Filament sources are identified two different ways and the numbering is not the same.
#
# A flat *slot* index is what print.ams_mapping and the cloud amsDetailMapping 'ams' field use.
# The four regular AMS units reserve slots 0-15 as 'unit * 4 + tray', and AMS HT units follow
# on from there at 16-23, one slot each. Observed in an amsDetailMapping entry pairing
# {'ams': 16} with {'amsId': 128, 'slotId': 0}.
#
# A *unit* id is what the module names (n3s/128), amsDetailMapping 'amsId' and the active tray
# report. Regular units are 0-3 and AMS HT units are 128-135.
AMS_TRAYS_PER_UNIT = 4
AMS_UNIT_COUNT = 4
AMS_SLOT_COUNT = AMS_UNIT_COUNT * AMS_TRAYS_PER_UNIT
AMS_HT_COUNT = 8
AMS_HT_SLOT_BASE = AMS_SLOT_COUNT
AMS_HT_SLOT_END = AMS_HT_SLOT_BASE + AMS_HT_COUNT
AMS_HT_UNIT_BASE = 128
AMS_HT_UNIT_END = AMS_HT_UNIT_BASE + AMS_HT_COUNT


def ams_slot_name(index: int) -> str | None:
    """Human readable name for an AMS slot index, or None if the index isn't a real slot."""
    if 0 <= index < AMS_SLOT_COUNT:
        return f"AMS {(index // AMS_TRAYS_PER_UNIT) + 1} Tray {(index % AMS_TRAYS_PER_UNIT) + 1}"

    # An AMS HT holds a single spool so there is no tray number to disambiguate. Accept the unit
    # id as well as the slot index since both numbering schemes appear in the payloads.
    if AMS_HT_SLOT_BASE <= index < AMS_HT_SLOT_END:
        return f"AMS HT {index - AMS_HT_SLOT_BASE + 1}"
    if AMS_HT_UNIT_BASE <= index < AMS_HT_UNIT_END:
        return f"AMS HT {index - AMS_HT_UNIT_BASE + 1}"

    return None


@dataclass
class PrintJob:
    """Return all information related content"""

    print_percentage: int
    gcode_state: str
    file_type_icon: str
    gcode_file: str
    gcode_file_downloaded: str
    _subtask_name: str
    model_id: str
    task_id: str
    plate_idx: int
    start_time: datetime
    end_time: datetime
    remaining_time: int
    current_layer: int
    total_layers: int
    print_error: int
    print_weight: float
    print_length: int
    print_bed_type: str
    _print_type: str
    _ams_print_weights: float
    _ams_print_lengths: float
    _skipped_objects: list
    _printable_objects: dict
    _gcode_file_prepare_percent: int
    _loaded_model_data: bool
    _ftpRunAgain: bool
    _ftpThread: threading.Thread
    _ftp_download_percentage: int

    def __init__(self, client):
        self._client = client
        self.print_percentage = 0
        self.gcode_state = "unknown"
        self.gcode_file = ""
        self.gcode_file_downloaded = ""
        self._subtask_name = ""
        self.model_id = ""
        self.task_id = ""
        self.plate_idx = 0
        self.start_time = None
        self.end_time = None
        self.remaining_time = 0
        self.current_layer = 0
        self.total_layers = 0
        self.print_error = 0
        self.print_weight = 0
        self.ams_mapping = []
        self._ams_print_weights = [0.0] * AMS_HT_UNIT_END # TODO: Convert to a dict in the future?
        self._ams_print_lengths = [0.0] * AMS_HT_UNIT_END # TODO: Convert to a dict in the future?
        self.print_length = 0
        self.print_bed_type = "unknown"
        self.file_type_icon = "mdi:file"
        self._print_type = ""
        self._printable_objects = {}
        self._skipped_objects = []
        self._gcode_file_prepare_percent = -1
        self._loaded_model_data = False
        self._ftpRunAgain = False
        self._ftpThread = None
        self._ftp_download_percentage = 100

    @property
    def model_download_percentage(self) -> int:
        return self._ftp_download_percentage

    @property
    def get_printable_objects(self) -> json:
        return self._printable_objects

    @property
    def get_skipped_objects(self) -> str:
        return self._skipped_objects
    
    @property
    def get_print_weights(self) -> dict:
        values = {}
        if self._client._device.external_spool[0].active:
            values["External Spool"] = self.print_weight
        elif self._client._device.external_spool[1].active:
            values["External Spool 2"] = self.print_weight
        else:
            for index, weight in enumerate(self._ams_print_weights):
                name = ams_slot_name(index)
                if weight != 0 and name is not None:
                    values[name] = weight
        return values

    @property
    def get_print_lengths(self) -> dict:
        values = {}
        if self._client._device.external_spool[0].active:
            values["External Spool"] = self.print_length
        elif self._client._device.external_spool[1].active:
            values["External Spool 2"] = self.print_length
        else:
            for index, length in enumerate(self._ams_print_lengths):
                name = ams_slot_name(index)
                if length != 0 and name is not None:
                    values[name] = length
        return values
    
    @property
    def subtask_name(self) -> str:
        return None if self._subtask_name == "" else self._subtask_name
    
    @property
    def print_type(self) -> str:
        return "unknown" if self._print_type == "" else self._print_type

    def print_update(self, data) -> bool:
        old_data = f"{self.__dict__}"

        # Example payload:
        # {
        #     "print": {
        #         "gcode_start_time": "1681479206",
        #         "gcode_state": "IDLE",
        #         "mc_print_stage": "1",
        #         "mc_percent": 100,
        #         "mc_remaining_time": 0,
        #         "wifi_signal": "-53dBm",
        #         "print_type": "idle",
        #         "ipcam": {
        #             "ipcam_dev": "1",
        #             "ipcam_record": "enable"
        #             "resolution": "1080p",        # X1 only
        #             "timelapse": "disable"
        #         },
        #         "layer_num": 0,
        #         "total_layer_num": 0,

        self.print_percentage = data.get("mc_percent", self.print_percentage)
        previous_gcode_state = self.gcode_state
        self.gcode_state = data.get("gcode_state", self.gcode_state)
        if self.gcode_state.lower() not in GCODE_STATE_OPTIONS:
            if self.gcode_state != '':
                LOGGER.error(f"Unknown gcode_state. Please log an issue : '{self.gcode_state}'")
            self.gcode_state = "unknown"
        if previous_gcode_state != self.gcode_state:
            LOGGER.debug(f"GCODE_STATE: {previous_gcode_state} -> {self.gcode_state}")
        old_gcode_file = self.gcode_file
        self.gcode_file = data.get("gcode_file", self.gcode_file)
        if old_gcode_file != self.gcode_file:
            LOGGER.debug(f"GCODE_FILE: {self.gcode_file}")
        self._print_type = data.get("print_type", self._print_type)
        if self._print_type.lower() not in PRINT_TYPE_OPTIONS:
            if self._print_type != "":
                LOGGER.debug(f"Unknown print_type. Please log an issue : '{self._print_type}'")
            self._print_type = "unknown"
        old_subtask_name = self._subtask_name
        self._subtask_name = data.get("subtask_name", self._subtask_name)
        if old_subtask_name != self._subtask_name:
            LOGGER.debug(f"SUBTASK_NAME: {self._subtask_name}")

        self.model_id = data.get("model_id", self.model_id)
        self.task_id = data.get("task_id", self.task_id)
        self.plate_idx = data.get("plate_idx", self.plate_idx)

        # Printer-initiated prints and reprints can reach RUNNING before the
        # printer reports a subtask name. In that case model data is initially
        # loaded using the newest 3mf on the printer as a fallback, which may
        # belong to an older print. Resolve the model again once the real task
        # name arrives so the cover image and metadata match the active print.
        if (
            old_subtask_name == ""
            and self._subtask_name != ""
            and self._loaded_model_data
            and self.gcode_state not in ("IDLE", "FAILED", "FINISH", "unknown")
        ):
            LOGGER.debug("SUBTASK_NAME ARRIVED AFTER MODEL DATA; RELOADING MODEL")
            self._clear_model_data()
            self._update_task_data()
        self.file_type_icon = "mdi:file" if self._print_type != "cloud" else "mdi:cloud-outline"
        self.current_layer = data.get("layer_num", self.current_layer)
        self.total_layers = data.get("total_layer_num", self.total_layers)
        self.ams_mapping = data.get("ams_mapping", self.ams_mapping)
        self._skipped_objects = data.get("s_obj", self._skipped_objects)

        # Initialize task data at startup.
        if previous_gcode_state == "unknown" and self.gcode_state != "unknown":
            self._update_task_data()
            self._download_timelapse()

        # Generate the end_time from the remaining_time mqtt payload value if present.
        if data.get("mc_remaining_time") is not None:
            existing_remaining_time = self.remaining_time
            self.remaining_time = data.get("mc_remaining_time")
            if existing_remaining_time != self.remaining_time:
                end_time = get_end_time(self.remaining_time)
                if end_time != self.end_time:
                    self.end_time = end_time
                    LOGGER.debug(f"END TIME2: {self.end_time}")

        # Handle print start
        previously_idle = previous_gcode_state == "IDLE" or previous_gcode_state == "FAILED" or previous_gcode_state == "FINISH"
        currently_idle = self.gcode_state == "IDLE" or self.gcode_state == "FAILED" or self.gcode_state == "FINISH"

        if previously_idle and not currently_idle:
            self._client.callback("event_print_started")

            # Sometimes the download completes so fast we go from a prior print's 100% to 100% for the new print in one update.
            # Make sure we catch that case too. And Lan Mode never sets this - make sure we init it to 0.
            self._gcode_file_prepare_percent = 0

            # Clear existing cover & pick image data before attempting any fresh download.
            self._clear_model_data()

            # Generate the start_time when printer moves from idle to another state. Original attempt with remaining time
            # becoming non-zero didn't work as it never bounced to zero in at least the scenario where a print was canceled.
            # We can use the existing get_end_time helper to format date.now() as desired by passing 0.
            self.start_time = get_end_time(0)
            # Make sure we don't keep using a stale end time.
            self.end_time = None
            LOGGER.debug(f"GENERATED START TIME: {self.start_time}")

            if not self._client.ftp_enabled:
                # We can update task data from the cloud immediately. But ftp has to wait.
                self._update_task_data()

        old_gcode_file_prepare_percent = self._gcode_file_prepare_percent
        self._gcode_file_prepare_percent = int(data.get("gcode_file_prepare_percent", str(self._gcode_file_prepare_percent)))
        if self.gcode_state == "PREPARE":
            LOGGER.debug(f"DOWNLOAD PERCENTAGE: {old_gcode_file_prepare_percent} -> {self._gcode_file_prepare_percent}")

        # If we are FTP enabled and we haven't yet downloaded the model data, see if we can now.
        if not self._loaded_model_data:
            if self._client._device.supports_feature(Features.SUPPORTS_EARLY_FTP_DOWNLOAD):
                if self.gcode_state == "PREPARE" and \
                    old_gcode_file_prepare_percent > 0 and \
                    old_gcode_file_prepare_percent != self._gcode_file_prepare_percent and \
                    self._gcode_file_prepare_percent >= 99:

                    # P1 sometimes only gets to 99% download and never reaches 100% so we treat 99% as complete.

                    # Now we can update the model data by ftp. By this point the model has been successfully loaded to the printer.
                    # and it's network stack is idle and shouldn't timeout or fail on us randomly.
                    LOGGER.debug(f"DOWNLOAD TO PRINTER IS COMPLETE")
                    self._update_task_data()

            if self.gcode_state == "RUNNING" and (previously_idle or previous_gcode_state == "PREPARE"):
                # We haven't yet downloaded model data off the printer. I've observed three scenarios where this happens:
                # 1. This is a lan mode print where the gcode was pushed to the printer before the print ever started so
                # 2. On the P1 I've observed a bug where the download completes but the gcode_file_prepare_percent never reaches 100.
                # If we transition to the running gcode_state without observing 100% we assume the download did actually complete.
                # 3. On the X1C for a local Bambu Studio slice sent via the cloud we see the download percentage immediately
                # jump to 100% at the same time we see the PREPARE phase start but if we try and download then, the model file
                # is not present.
                LOGGER.debug("REACHED RUNNING WITHOUT DOWNLOADING MODEL")
                self._update_task_data()

        # When a print is canceled by the user, this is the payload that's sent. A couple of seconds later
        # print_error will be reset to zero.
        # {
        #     "print": {
        #         "print_error": 50348044,
        #     }
        # }
        timelapseDownloaded = False
        isCanceledPrint = False
        if data.get("print_error") == 50348044 and self.print_error == 0:
            isCanceledPrint = True
            self._download_timelapse()
            timelapseDownloaded = True
            self._client.callback("event_print_canceled")
        self.print_error = data.get("print_error", self.print_error)

        # Handle print failed
        if previous_gcode_state != "unknown" and previous_gcode_state != "FAILED" and self.gcode_state == "FAILED":
            if not isCanceledPrint:
                self._client.callback("event_print_failed")
                if not timelapseDownloaded:
                    self._download_timelapse()
                    timelapseDownloaded = True

        # Handle print finish
        if previous_gcode_state != "unknown" and previous_gcode_state != "FINISH" and self.gcode_state == "FINISH":
            if not timelapseDownloaded:
                self._download_timelapse()
                timelapseDownloaded = True
            self._client.callback("event_print_finished")

        if currently_idle and not previously_idle and previous_gcode_state != "unknown":
            if self.start_time != None:
                # self.end_time isn't updated if we hit an AMS retract at print end but the printer does count that entire
                # paused time as usage hours. So we need to use the current time instead of the last recorded end time in
                # our calculation here.
                duration = get_end_time(0) - self.start_time
                # Round usage hours to 2 decimal places (about 1/2 a minute accuracy)
                new_hours = round((duration.seconds / 60 / 60) * 100) / 100
                LOGGER.debug(f"NEW USAGE HOURS: {new_hours}")
                self._client._device.info.usage_hours += new_hours

        return (old_data != f"{self.__dict__}")

    # FTP implementation differences between P1 and X1 printers:
    # - X1 includes the path in the returned filenames for the NLST command
    # - P1 just returns the bare filename
    #
    # Known filepath configurations:
    # 
    # X1 lan mode print
    #   Orca 2.2.0 'print' of 3mf file
    #     "gcode_file": "/data/Metadata/plate_1.gcode",
    #     "subtask_name": "Clamshell Parts Box",
    #     FILE: /Clamshell Parts Box.gcode.3mf
    #
    # P1 lan mode print:
    #   Bambu Studio 'print' of 3mf file
    #     "gcode_file": "36mm.gcode.3mf",
    #     "subtask_name": "36mm",
    #     FILE: /36mm.gcode.3mf
    #
    # X1C cloud print:
    #   Bambu Studio 'print' of unsaved workspace
    #     gcode_filename = data/metadata/plate_1.gcode (ramdisk - not accessible via ftp)
    #     subtask_name = FILENAME
    #     FILE: /cache/FILENAME.3mf
    #
    # P1 cloud print:
    #   Bambu Studio 'print' of unsaved workspace
    #     gcode_filename = Cube + Cube + Cube + Cube + Cube.3mf
    #     subtask_name = Cube + Cube + Cube + Cube + Cube
    #     FILE: /cache/Cube + Cube + Cube + Cube + Cube.3mf
    #
    # X1 cloud print:
    #   Makerworld print
    #     gcode_filename = /data/metadata/plate_3.gcode
    #     subtask_name = Lovers Valentine Day Shadowbox
    #     FILE: /cache/Lovers Valentine Day Shadowbox.3mf
    # 
    # P1 cloud print:
    #   Makerworld print
    #     gcode_filename = Lovers Valentine Day Shadowbox.3mf
    #     subtask_name = Lovers Valentine Day Shadowbox
    #     FILE: /cache/Lovers Valentine Day Shadowbox.3mf
    # 

    def _remote_media_sources(self) -> list[RemoteMediaSource]:
        if not self._client.ftp_enabled:
            return []

        try:
            self._client.probe_remote_media_sources()
        except Exception as e:
            LOGGER.debug(f"Remote media source probe failed during media trigger: {type(e)} Args: {e}")

        sources: list[RemoteMediaSource] = []
        if self._client.tcp6000_media_supported is True:
            sources.append(Tcp6000MediaSource(self._client))
        sources.append(Ftps990MediaSource(self._client))
        return sources

    def _close_remote_media_sources(self, sources: list[RemoteMediaSource]) -> None:
        for source in sources:
            try:
                source.close()
            except Exception:
                pass

    def _collect_remote_files(
        self,
        sources: list[RemoteMediaSource],
        media_type: str,
        extensions: list[str],
        ftps_search_paths: list[str] | None = None,
    ) -> list[RemoteMediaFile]:
        files: list[RemoteMediaFile] = []
        for source in sources:
            try:
                source_files = source.list_files(
                    media_type=media_type,
                    extensions=extensions,
                    search_paths=ftps_search_paths if source.name == Ftps990MediaSource.name else None,
                )
                LOGGER.debug(
                    f"{source.name} found {len(source_files)} {media_type} candidate(s)"
                )
                files.extend(source_files)
            except Exception as e:
                LOGGER.debug(
                    f"{source.name} failed listing {media_type}: {type(e)} Args: {e}"
                )
        return sort_newest_first(dedupe_remote_files(files))

    def _download_remote_file_atomic(
        self,
        source: RemoteMediaSource,
        remote_file: RemoteMediaFile,
        final_path: Path,
        progress_callback: ProgressCallback | None = None,
    ) -> int:
        final_path.parent.mkdir(parents=True, exist_ok=True)
        part_path = Path(f"{final_path}.part")
        try:
            if part_path.exists():
                part_path.unlink()
        except Exception:
            pass

        try:
            downloaded_size = source.download_file(
                remote_file,
                part_path,
                progress_callback=progress_callback,
            )
            expected_size = int(remote_file.size or 0)
            if expected_size > 0 and downloaded_size != expected_size:
                raise RemoteMediaError(
                    f"Remote download size mismatch for {remote_file.path}: "
                    f"{downloaded_size} != {expected_size}"
                )
            os.replace(part_path, final_path)
            return downloaded_size
        except Exception:
            try:
                if part_path.exists():
                    part_path.unlink()
            except Exception:
                pass
            raise

    def _same_remote_media_file(self, left: RemoteMediaFile, right: RemoteMediaFile) -> bool:
        if left.media_type != right.media_type:
            return False
        if canonical_storage(left.storage) != canonical_storage(right.storage):
            return False
        left_path = left.path.replace("\\", "/").strip("/").lower()
        right_path = right.path.replace("\\", "/").strip("/").lower()
        if left_path and right_path and left_path == right_path:
            return True
        if left.size > 0 and right.size > 0 and left.size != right.size:
            return False
        return left.basename.lower() == right.basename.lower()

    def _remote_file_aliases(
        self,
        remote_files: list[RemoteMediaFile],
        selected: RemoteMediaFile,
    ) -> list[RemoteMediaFile]:
        aliases = [
            file for file in remote_files
            if self._same_remote_media_file(file, selected)
        ]
        return sorted(
            aliases,
            key=lambda file: (source_priority(file.source), file.sort_time, file.size),
            reverse=True,
        )

    def _remote_file_is_stable(
        self,
        source: RemoteMediaSource,
        remote_file: RemoteMediaFile,
        media_type: str,
        extensions: list[str],
        ftps_search_paths: list[str] | None = None,
        wait_seconds: float = 1.0,
    ) -> bool:
        expected_size = int(remote_file.size or 0)
        if expected_size <= 0:
            return True

        time.sleep(wait_seconds)
        try:
            refreshed_files = source.list_files(
                media_type=media_type,
                extensions=extensions,
                search_paths=ftps_search_paths if source.name == Ftps990MediaSource.name else None,
            )
        except Exception as e:
            LOGGER.debug(
                f"Could not confirm remote file stability for {remote_file.path}: {type(e)} Args: {e}"
            )
            return True

        refreshed = next(
            (file for file in refreshed_files if self._same_remote_media_file(file, remote_file)),
            None,
        )
        if refreshed is None:
            LOGGER.debug(f"Remote file disappeared before download: {remote_file.path}")
            return False
        if int(refreshed.size or 0) != expected_size:
            LOGGER.debug(
                f"Remote file is still changing: {remote_file.path} "
                f"{expected_size} -> {refreshed.size}"
            )
            return False
        return True

    def _model_filenames_to_try(self) -> list[str]:
        filenames_to_try = []

        if self._subtask_name != '':
            if self._subtask_name.endswith('.3mf'):
                filenames_to_try.append(self._subtask_name)
            else:
                filenames_to_try.append(f"{self._subtask_name}.3mf")
                filenames_to_try.append(f"{self._subtask_name}.gcode.3mf")

        if (self.gcode_file != '') and (self._subtask_name != self.gcode_file):
            if self.gcode_file.endswith('.3mf'):
                filenames_to_try.append(self.gcode_file)
            else:
                filenames_to_try.append(f"{self.gcode_file}.3mf")
                filenames_to_try.append(f"{self.gcode_file}.gcode.3mf")

        return filenames_to_try

    def _remote_model_matches(self, remote_file: RemoteMediaFile, candidate: str) -> bool:
        candidate = candidate.replace("\\", "/").lstrip("/")
        remote_path = remote_file.path.replace("\\", "/").lstrip("/")
        remote_name = remote_file.basename.replace("\\", "/")
        return remote_path == candidate or remote_name == candidate.rsplit("/", 1)[-1]

    def _model_candidate_score(self, remote_file: RemoteMediaFile) -> tuple[int, datetime, int, int]:
        path = remote_file.path.replace("\\", "/").lower()
        name = remote_file.basename.lower()
        in_cache = 1 if "/cache/" in path or path.startswith("cache/") else 0
        gcode_3mf = 1 if name.endswith(".gcode.3mf") else 0
        source_rank = 1 if remote_file.source == Tcp6000MediaSource.name else 0
        return (in_cache, remote_file.sort_time, gcode_3mf, source_rank)

    def _select_model_file(
        self,
        remote_files: list[RemoteMediaFile],
        filenames_to_try: list[str],
    ) -> RemoteMediaFile | None:
        selected_files = self._select_model_files(remote_files, filenames_to_try)
        return selected_files[0] if selected_files else None

    def _select_model_files(
        self,
        remote_files: list[RemoteMediaFile],
        filenames_to_try: list[str],
    ) -> list[RemoteMediaFile]:
        remote_files = [file for file in remote_files if "Metadata" not in file.path]
        for filename in filenames_to_try:
            matches = [
                file for file in remote_files
                if self._remote_model_matches(file, filename)
            ]
            if matches:
                selected = sorted(matches, key=self._model_candidate_score, reverse=True)[0]
                LOGGER.debug(
                    f"Selected model candidate {selected.path} from {selected.source}/{selected.storage}"
                )
                return self._remote_file_aliases(matches, selected)

        if self._subtask_name == "":
            LOGGER.debug("Falling back to newest remote 3mf file across media sources.")
            sorted_files = sort_newest_first(remote_files)
            if not sorted_files:
                return []
            return self._remote_file_aliases(remote_files, sorted_files[0])

        return []

    def _model_cache_paths(self, remote_file: RemoteMediaFile) -> tuple[Path, Path]:
        cache_root = Path(self._client.cache_path) / "prints"
        size = int(remote_file.size)
        filename = remote_file.basename

        if remote_file.source == Ftps990MediaSource.name:
            relative_path = Path(remote_file.path.lstrip('/'))
            subdir = relative_path.parent
        else:
            subdir = Path("cache")

        if size <= 0:
            cache_file_path = cache_root / subdir / filename
            cache_file_path_legacy = cache_file_path
        elif filename.startswith(f"{size}-"):
            cache_file_path = cache_root / subdir / filename
            cache_file_path_legacy = cache_root / subdir / filename.removeprefix(f"{size}-")
        else:
            cache_file_path = cache_root / subdir / f"{size}-{filename}"
            cache_file_path_legacy = cache_root / subdir / filename

        return cache_file_path, cache_file_path_legacy

    def _download_model_file_from_remote(
        self,
        source: RemoteMediaSource,
        remote_file: RemoteMediaFile,
        progress_callback=None,
    ) -> str | None:
        cache_file_path, cache_file_path_legacy = self._model_cache_paths(remote_file)
        size = int(remote_file.size)
        cache_file_path.parent.mkdir(parents=True, exist_ok=True)

        if size > 0 and cache_file_path.exists() and cache_file_path.stat().st_size == size:
            LOGGER.debug(f"File already in cache: {cache_file_path}")
            os.utime(cache_file_path, None)
            return str(cache_file_path)

        if size > 0 and cache_file_path_legacy.exists() and cache_file_path_legacy.stat().st_size == size:
            LOGGER.debug(f"File already in legacy cache: {cache_file_path_legacy}")
            extensions = [
                ".3mf",
                ".gcode",
                ".png",
                ".slice_info.config",
            ]
            for extension in extensions:
                src = cache_file_path_legacy.with_suffix("").with_suffix(extension)
                dst = cache_file_path.with_suffix("").with_suffix(extension)
                if src.exists():
                    LOGGER.debug(f"Moving {src} -> {dst}")
                    try:
                        shutil.move(str(src), str(dst))
                    except Exception as e:
                        LOGGER.debug(f"Failed moving {src} -> {dst}: {e}")
            os.utime(cache_file_path, None)
            return str(cache_file_path)

        total_start_time = time.time()
        last_percentage = -1
        self._ftp_download_percentage = 0

        def download_progress_callback(percentage: int) -> None:
            nonlocal last_percentage
            if last_percentage == percentage:
                return
            LOGGER.debug(f"Remote model download progress: {percentage:.0f}%")
            self._ftp_download_percentage = int(percentage)
            last_percentage = percentage
            self._client.callback("event_printer_data_update")
            if progress_callback:
                progress_callback(percentage)

        try:
            downloaded_size = self._download_remote_file_atomic(
                source,
                remote_file,
                cache_file_path,
                progress_callback=download_progress_callback,
            )
            self._ftp_download_percentage = 100
            download_time = time.time() - total_start_time
            download_speed = downloaded_size / download_time if download_time > 0 else 0
            LOGGER.debug(
                f"Successfully downloaded '{remote_file.path}' from {remote_file.source}/"
                f"{remote_file.storage} to cache. Time: {download_time:.0f}s, "
                f"Speed: {download_speed/1024:.0f} KB/s"
            )
            return str(cache_file_path)
        except Exception as e:
            LOGGER.debug(
                f"Failed downloading model {remote_file.path} from {remote_file.source}/"
                f"{remote_file.storage}: {type(e)} Args: {e}"
            )
            return None

    def _attempt_remote_model_download(self, sources: list[RemoteMediaSource]) -> str | None:
        filenames_to_try = self._model_filenames_to_try()
        remote_files = self._collect_remote_files(
            sources,
            media_type="model",
            extensions=['.3mf'],
            ftps_search_paths=self.ftp_search_paths,
        )
        selected_files = self._select_model_files(remote_files, filenames_to_try)
        if not selected_files:
            return None

        for selected in selected_files:
            source = next((item for item in sources if item.name == selected.source), None)
            if source is None:
                LOGGER.debug(f"No media source object found for selected model source {selected.source}")
                continue
            if not self._remote_file_is_stable(
                source,
                selected,
                media_type="model",
                extensions=['.3mf'],
                ftps_search_paths=self.ftp_search_paths,
            ):
                continue

            result = self._download_model_file_from_remote(source, selected)
            if result is not None:
                return result

        return None

    # The cached files also include the file size appended to them so that new prints of the same model
    # filename but different settings can be cached independently. This keeps the print history truer and
    # allows reprints of earlier prints that had the same name.
    #
    # The legacy caching approach just put them in a matching path in the local cache for
    # the printer. If we encounter that, we move the files to the new size-based subdirectory.
    def _attempt_ftp_download_of_file(self, ftp, file_path, progress_callback=None):
        if 'Metadata' in file_path:
            # This is a ram drive on the X1 and is not accessible via FTP
            return None

        cache_root = os.path.join(self._client.cache_path, "prints")

        try:
            LOGGER.debug(f"Looking for '{file_path}'")
            size = int(ftp.size(file_path))
            LOGGER.debug(f"File exists. Size: {size} bytes.")

            relative_path = Path(file_path.lstrip('/'))
            subdir = relative_path.parent
            filename = relative_path.name

            if filename.startswith(f"{size}-"):
                # Craft legacy cache filepath for backwards compatibility:
                cache_file_path = Path(cache_root) / subdir / filename
                cache_file_path_legacy = Path(cache_root) / subdir / filename.removeprefix(f"{size}-")
            else:
                cache_file_path = Path(cache_root) / subdir / f"{size}-{filename}"
                cache_file_path_legacy = Path(cache_root) / subdir / filename

            # Ensure the directory exists
            cache_file_path.parent.mkdir(parents=True, exist_ok=True)

            # First check the new cache file path:
            if cache_file_path.exists() and cache_file_path.stat().st_size == size:
                LOGGER.debug(f"File already in cache: {cache_file_path}")
                # Update last edited time to refresh its cache lifetime and print order in history.
                os.utime(cache_file_path, None)
                return str(cache_file_path)

            # Check the legacy path second for backwards compatibility.
            if cache_file_path_legacy.exists() and cache_file_path_legacy.stat().st_size == size:
                LOGGER.debug(f"File already in cache: {cache_file_path_legacy}")
                # File exists but in the old naming scheme. Move files to new location.
                extensions = [
                    ".3mf",
                    ".gcode",
                    ".png",
                    ".slice_info.config",
                ]
                # Base path without the final suffix (so we can swap extensions)
                for extension in extensions:
                    src = cache_file_path_legacy.with_suffix("").with_suffix(extension)
                    dst = cache_file_path.with_suffix("").with_suffix(extension)
                    if src.exists():
                        LOGGER.debug(f"Moving {src} -> {dst}")
                        try:
                            shutil.move(str(src), str(dst))
                        except Exception as e:
                            LOGGER.debug(f"Failed moving {src} -> {dst}: {e}")

                # Update last edited time to refresh it's cache lifetime and print order in history.
                os.utime(cache_file_path, None)
                return str(cache_file_path)

            # Download to cache with progress tracking
            total_downloaded = 0
            start_time = time.time()
            last_log_percentage = 0

            self._ftp_download_percentage = 0
            def download_progress_callback(data):
                nonlocal total_downloaded, last_log_percentage
                try:
                    total_downloaded += len(data)
                    percentage = int((total_downloaded / size) * 100)
                    
                    # Only log every 10 seconds
                    current_time = time.time()
                    if last_log_percentage != percentage:
                        LOGGER.debug(f"FTP download progress: {percentage:.0f}% ({total_downloaded//1024}/{size//1024} KB)")
                        self._ftp_download_percentage = int(percentage)
                        last_log_percentage = percentage
                        self._client.callback("event_printer_data_update")
                    
                    if progress_callback:
                        progress_callback(percentage)
                except Exception as e:
                    LOGGER.debug(f"Error in progress callback: {e}")
                    # Don't let progress callback errors break the download

            with open(str(cache_file_path), 'wb') as f:
                # Create a wrapper function that combines file writing and progress tracking
                def write_with_progress(data):
                    f.write(data)
                    download_progress_callback(data)
                
                ftp.retrbinary(f"RETR {file_path}", write_with_progress)
                f.flush()
            
            # Calculate download statistics
            self._ftp_download_percentage = 100
            end_time = time.time()
            download_time = end_time - start_time
            download_speed = size / download_time if download_time > 0 else 0
            
            LOGGER.debug(f"Successfully downloaded '{file_path}' to cache. Time: {download_time:.0f}s, Speed: {download_speed/1024:.0f} KB/s")
            return str(cache_file_path)
                    
        except ftplib.error_perm as e:
             if '550' not in str(e.args): # 550 is unavailable.
                 LOGGER.debug(f"Failed to download model at '{file_path}': {e}")
        except Exception as e:
            LOGGER.debug(f"Unexpected exception at '{file_path}': {type(e)} Args: {e}")
            # Optionally add retry logic here
            pass
        return None

    ftp_search_paths = ['/cache/', '/']
    def _attempt_ftp_download_of_file_from_search_path(self, ftp, filename):
        for path in self.ftp_search_paths:
            file_path = f"{path}{filename.lstrip('/')}"
            result = self._attempt_ftp_download_of_file(ftp, file_path)
            if result is not None:
                return result
        return None

    def _attempt_ftp_download(self, ftp) -> Union[str, None]:

        filenames_to_try = []

        # First test if the subtaskname exists as a 3mf
        if self._subtask_name != '':
            if self._subtask_name.endswith('.3mf'):
                filenames_to_try.append(self._subtask_name)
            else:
                filenames_to_try.append(f"{self._subtask_name}.3mf")
                filenames_to_try.append(f"{self._subtask_name}.gcode.3mf")


        # If we didn't find it then try the gcode file
        if (self.gcode_file != '') and (self._subtask_name != self.gcode_file):
            if self.gcode_file.endswith('.3mf'):
                filenames_to_try.append(self.gcode_file)
            else:
                filenames_to_try.append(f"{self.gcode_file}.3mf")
                filenames_to_try.append(f"{self.gcode_file}.gcode.3mf")

        # Try each candidate filename in order
        for filename in filenames_to_try:
            model_file = self._attempt_ftp_download_of_file_from_search_path(ftp, filename=filename)
            if model_file is not None:
                return model_file

        if self._subtask_name == "":
            # Fall back to find the latest file by timestamp but only if we don't have a subtask name set - printer must have been rebooted.
            LOGGER.debug("Falling back to searching for latest 3mf file.")
            model_path = self._find_latest_file(ftp, self.ftp_search_paths, ['.3mf'])
            if model_path is not None:
                model_file_path = self._attempt_ftp_download_of_file(ftp, model_path)
                return model_file_path

        return None
    
    def _find_latest_file(self, ftp, search_paths, extensions: list):
        # Look for the newest file with extension in directory.
        file_list = []
        def parse_line(path: str, line: str):
            # Example line content:
            # -rw-r--r--    1 1000     1000      1632221 Jun 17  2025 video_2025-06-17_12-12-18.mp4
            # -rw-r--r--    1 1000     1000      1640240 Jun 18 00:27 video_2025-06-17_14-48-33.mp4
            # (retrieved on 12/16/2025)

            # Match the line format: '-rw-rw-rw- 1 user group 1234 Jan 01 12:34 filename'
            pattern_with_time_no_year      = r'^\S+\s+\d+\s+\S+\s+\S+\s+\d+\s+(\S+\s+\d+\s+\d+:\d+)\s+(.+)$'
            # Match the line format: '-rw-rw-rw- 1 user group 1234 Jan 01 2024 filename'
            pattern_without_time_just_year = r'^\S+\s+\d+\s+\S+\s+\S+\s+\d+\s+(\S+\s+\d+\s+\d+)\s+(.+)$'
            match = re.match(pattern_with_time_no_year, line)
            #LOGGER.debug(line)
            if match:
                timestamp_str, filename = match.groups()
                _, extension = os.path.splitext(filename)
                if extension in extensions:
                    # Since these dates don't have the year we have to work it out. For the most part that is going to be
                    # the current year, but we need to handle the case where the file is from December and now it's January
                    # or the file is from January but it's currently December because we've just passed through the New Year.
                    # The transition from without year to with year is ~6 months in the past.
                    timestamp = datetime.strptime(timestamp_str, '%b %d %H:%M')
                    timestamp = timestamp.replace(tzinfo=timezone.utc)
                    utc_time_now = datetime.now().astimezone(timezone.utc)

                    # Initially assume current year, then adjust if the parsed time would be more than ~6 months away from now
                    timestamp = timestamp.replace(year=utc_time_now.year)
                    delta = timestamp - utc_time_now
                    six_months = timedelta(days=190) # Slightly more than 6 months to be safe

                    # If the timestamp is more than six months in the future, it's really from the previous year. This will be a
                    # common case for files from the previous year until we reach mid-year current time.
                    if delta > six_months:
                        timestamp = timestamp.replace(year=utc_time_now.year - 1)

                    # If the timestamp is more than six months in the past, it's from next year. Should be rare but could happen
                    # as the timezone the printer uses is not consistent. Sometimes it's UTC+8 (China), sometimes UTC, sometimes
                    # local + day light savings. So we could end up with a slightly future time (ignoring year) that becomes way
                    # in the past when we assign the current year right before new years.
                    elif delta < -six_months:
                        timestamp = timestamp.replace(year=utc_time_now.year + 1)

                    return timestamp, f"{path}/{filename}" if path != '/' else f"/{filename}"
                else:
                    return None

            match = re.match(pattern_without_time_just_year, line)
            if match:
                timestamp_str, filename = match.groups()
                _, extension = os.path.splitext(filename)
                if extension in extensions:
                    timestamp = datetime.strptime(timestamp_str, '%b %d %Y')
                    timestamp = timestamp.replace(tzinfo=timezone.utc)
                    return timestamp, f"{path}/{filename}" if path != '/' else f"/{filename}"
                else:
                    return None
            
            LOGGER.debug(f"UNEXPECTED LIST LINE FORMAT: '{line}'")
            return None

        # Attempt to find the model in one of many known directories
        for path in search_paths:
            try:
                LOGGER.debug(f"Looking for latest {extensions} file in {path}")
                ftp.retrlines(f"LIST {path}", lambda line: file_list.append(file) if (file := parse_line(path, line)) is not None else None)
                LOGGER.debug(f"Completed FTP list for {path}")
            except Exception as e:
                LOGGER.error(f"FTP list Exception. Type: {type(e)} Args: {e}")
                pass


        files = sorted(file_list, key=lambda file: file[0], reverse=True)
        for file in files:
            for extension in extensions:
                if file[1].endswith(extension):
                    if extension in extensions:
                        LOGGER.debug(f"Found latest file {file[1]} with timestamp {file[0]}")
                        return file[1]

        return None

    async def async_prune_print_history_files(self):
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.prune_print_history_files)
    
    def prune_print_history_files(self):
        if self._client._test_mode:
            return
        cache_file_path = os.path.join(self._client.cache_path, "prints")
        self._prune_old_files(directory=cache_file_path,
                              extensions=['.3mf'],
                              keep=self._client._print_cache_count,
                              extra_extensions=['.jpg', '.jpeg', '.png', '.slice_info.config', '.gcode'])

    async def async_prune_timelapse_files(self):
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.prune_timelapse_files)

    def prune_timelapse_files(self):
        if self._client._test_mode:
            return
        LOGGER.debug("Pruning timelapse history")
        cache_file_path = os.path.join(self._client.cache_path, "timelapse")
        self._prune_old_files(directory=cache_file_path,
                              extensions=['.mp4','.avi','.mov'],
                              keep=self._client._timelapse_cache_count,
                              extra_extensions=['.jpg', '.jpeg', '.png'])
            
    def _cleanup_stale_part_files(self, dir_path: Path, older_than_seconds: int = 24 * 60 * 60) -> int:
        cutoff_time = time.time() - older_than_seconds
        deleted_count = 0
        for part_file in dir_path.rglob("*.part"):
            if not part_file.is_file():
                continue
            try:
                if os.path.getmtime(part_file) >= cutoff_time:
                    continue
                os.remove(part_file)
                deleted_count += 1
                LOGGER.debug(f"Deleted stale partial download: {part_file}")
            except Exception as e:
                LOGGER.error(f"Failed to delete stale partial download {part_file}: {e}")
        return deleted_count

    def _prune_old_files(self, directory: str, extensions: List[str], keep: int, extra_extensions=None):
        dir_path = Path(directory)
        if not dir_path.is_dir():
            return

        self._cleanup_stale_part_files(dir_path)

        if keep == -1:
            # Cache pruning is disabled.
            LOGGER.debug("Skipping as pruning is disabled.")
            return

        if extra_extensions is None:
            extra_extensions = []
        
        LOGGER.debug(f"{dir_path}")

        extension_set = {extension.lower() for extension in extensions}
        
        # Get list of files matching the provided list of extensions
        matching_files = [
            f for f in dir_path.rglob('*')            
            if f.is_file() and f.suffix.lower() in extension_set
        ]
        
        # Sort files by last modification time, newest first
        matching_files.sort(key=lambda x: os.path.getmtime(x), reverse=True)

        # Files to delete: those beyond the 'keep' most recent
        old_files = matching_files[keep:]

        LOGGER.debug(f"Keeping up to {keep} files. Deleting {len(old_files)} excess files.")
        
        for primary_file in old_files:
            try:
                os.remove(primary_file )
                LOGGER.debug(f"Deleted: {primary_file }")
            except Exception as e:
                LOGGER.error(f"Failed to delete {primary_file}: {e}")
                continue

            # Get base name without extension
            base_name = os.path.splitext(primary_file)[0]

            # Delete associated files with alternate extensions
            for ext in extra_extensions:
                assoc_file = base_name + ext
                if os.path.exists(assoc_file):
                    try:
                        os.remove(assoc_file)
                        LOGGER.debug(f"Deleted associated: {assoc_file}")
                    except Exception as e:
                        LOGGER.error(f"Failed to delete associated {assoc_file}: {e}")

    def _timelapse_cache_path(self, remote_file: RemoteMediaFile) -> Path:
        if remote_file.source == Ftps990MediaSource.name:
            return Path(self._client.cache_path) / remote_file.path.lstrip('/')

        storage_segment = storage_cache_segment(remote_file.storage)
        return Path(self._client.cache_path) / "timelapse" / storage_segment / remote_file.basename

    def _download_timelapse_thumbnail(
        self,
        source: RemoteMediaSource,
        remote_file: RemoteMediaFile,
        local_file_path: Path,
    ) -> None:
        filename_without_extension, _ = os.path.splitext(remote_file.basename)
        thumbnail_filename = f"{filename_without_extension}.jpg"
        thumbnail_local_path = local_file_path.parent / thumbnail_filename
        if thumbnail_local_path.exists():
            return

        remote_dir = os.path.dirname(remote_file.path.replace("\\", "/"))
        if remote_dir:
            thumbnail_path = f"{remote_dir}/thumbnail/{thumbnail_filename}"
        else:
            thumbnail_path = f"thumbnail/{thumbnail_filename}"

        thumbnail_remote = RemoteMediaFile(
            name=thumbnail_filename,
            path=thumbnail_path,
            size=0,
            media_type="timelapse",
            source=remote_file.source,
            storage=remote_file.storage,
            modified=remote_file.modified,
        )

        try:
            LOGGER.debug(f"Downloading timelapse thumbnail '{thumbnail_path}'")
            self._download_remote_file_atomic(source, thumbnail_remote, thumbnail_local_path)
        except Exception as e:
            LOGGER.debug(
                f"Failed to download timelapse thumbnail {thumbnail_path}: {type(e)} Args: {e}"
            )
    
    def _download_timelapse(self):
        # If we are running in connection test mode, skip updating the last print task data.
        if self._client._test_mode:
            return
        if not self._client.ftp_enabled:
            return
        if self._client._timelapse_cache_count == 0:
            return
        thread = threading.Thread(target=self._async_download_timelapse)
        thread.start()
        
    def _async_download_timelapse(self):
        current_thread = threading.current_thread()
        current_thread.setName(f"{self._client._device.info.device_type}-Media-{threading.get_native_id()}")
        start_time = datetime.now()
        LOGGER.debug("Downloading latest timelapse from remote media sources")

        sources = self._remote_media_sources()
        try:
            video_extensions = ['.mp4','.avi','.mov']
            candidates = self._collect_remote_files(
                sources,
                media_type="timelapse",
                extensions=video_extensions,
                ftps_search_paths=['/timelapse'],
            )
            if not candidates:
                LOGGER.debug("No remote timelapse candidates found.")
            else:
                selected_aliases = self._remote_file_aliases(candidates, candidates[0])
                for remote_file in selected_aliases:
                    source = next((item for item in sources if item.name == remote_file.source), None)
                    if source is None:
                        LOGGER.debug(f"No media source object found for selected timelapse source {remote_file.source}")
                        continue
                    if not self._remote_file_is_stable(
                        source,
                        remote_file,
                        media_type="timelapse",
                        extensions=video_extensions,
                        ftps_search_paths=['/timelapse'],
                        wait_seconds=2.0,
                    ):
                        continue

                    try:
                        local_file_path = self._timelapse_cache_path(remote_file)
                        should_download = False
                        if local_file_path.exists():
                            local_file_size = local_file_path.stat().st_size
                            if remote_file.size > 0 and local_file_size == remote_file.size:
                                LOGGER.debug("Timelapse file found in cache.")
                                os.utime(local_file_path, None)
                            else:
                                LOGGER.debug(
                                    f"Timelapse file size differs (local: {local_file_size}, "
                                    f"remote: {remote_file.size}). Re-downloading."
                                )
                                should_download = True
                        else:
                            LOGGER.debug("Timelapse file doesn't exist locally. Downloading.")
                            should_download = True

                        if should_download:
                            LOGGER.debug(
                                f"Downloading timelapse '{remote_file.path}' from "
                                f"{remote_file.source}/{remote_file.storage}"
                            )
                            self._download_remote_file_atomic(source, remote_file, local_file_path)

                        self._download_timelapse_thumbnail(source, remote_file, local_file_path)
                        break
                    except Exception as e:
                        LOGGER.debug(
                            f"Failed downloading timelapse {remote_file.path} from "
                            f"{remote_file.source}/{remote_file.storage}: {type(e)} Args: {e}"
                        )
        finally:
            self._close_remote_media_sources(sources)

        end_time = datetime.now()

        self.prune_timelapse_files()

        LOGGER.debug(f"Done downloading timelapse from remote media. Elapsed time = {(end_time-start_time).seconds}s") 

    def _update_task_data(self):
        self._loaded_model_data = True

        # If we are running in connection test mode, skip updating the last print task data.
        if self._client._test_mode:
            return
        
        self._download_task_data_from_cloud()
        if self._client.ftp_enabled:
            self._download_task_data_from_printer()

    def _download_task_data_from_printer(self):
        if self._ftpThread is None:
            # Only start a new thread if there
            LOGGER.debug("Starting remote media thread.")
            self._ftpThread = threading.Thread(target=self._async_download_task_data_from_printer)
            self._ftpThread.start()
        else:
            LOGGER.debug("Remote media thread already running.")
            self._ftpRunAgain = True

    def _clear_model_data(self):
        LOGGER.debug("Clearing model data")
        self._loaded_model_data = False
        self._client._device.cover_image.set_image(None)
        self._clear_pick_data()

    def _clear_pick_data(self):
        LOGGER.debug("Clearing pick data")
        self._client._device.pick_image.set_image(None)
        self._printable_objects = {}

    def _async_download_task_data_from_printer(self):
        current_thread = threading.current_thread()
        current_thread.setName(f"{self._client._device.info.device_type}-Media-{threading.get_native_id()}")
        LOGGER.debug(f"Remote media thread starting.")

        try:
            while True:
                self._ftpRunAgain = False
                start_time = datetime.now()
                self._async_download_task_data_from_printer_worker()
                if not self._ftpRunAgain:
                    break
                end_time = datetime.now()
                LOGGER.debug(f"Remote media thread re-running. Elapsed time = {(end_time-start_time).seconds}s")
        except Exception as e:
            LOGGER.error(f"Remote media thread failed with exception {e}")

        end_time = datetime.now()
        LOGGER.info(f"Remote media thread exiting. Elapsed time = {(end_time-start_time).seconds}s")
        self._ftpThread = None

    def _async_download_task_data_from_printer_worker(self):
        model_file_path = None
        sources = self._remote_media_sources()
        try:
            for i in range(1,13):
                model_file_path = self._attempt_remote_model_download(sources)
                if model_file_path is not None:
                    break

                if not self._client._device.supports_feature(Features.SUPPORTS_EARLY_FTP_DOWNLOAD):
                    # The X1 has a weird behavior where the downloaded file doesn't exist for several seconds into the RUNNING phase and even
                    # then it is still being downloaded in place so we might try to grab it mid-download and get a corrupt file. Try 13 times
                    # 5 seconds apart over 60s.
                    if i != 12:
                        LOGGER.debug(f"Sleeping 5s for X1/H2/P2 retry")
                        time.sleep(5)
                        LOGGER.debug(f"Try #{i+1} for X1/H2/P2")
                else:
                    break
        finally:
            self._close_remote_media_sources(sources)

        if model_file_path is None:
            LOGGER.debug("No model file found.")
            return

        result = False
        
        try:
            LOGGER.debug(f"File size is {os.path.getsize(model_file_path)} bytes")

            model_dir = os.path.dirname(model_file_path)

            # Open the 3mf zip archive
            with ZipFile(model_file_path) as archive:
                # Extract the slicer XML config and parse the plate tree
                plate = ElementTree.fromstring(archive.read('Metadata/slice_info.config')).find('plate')
                
                # Iterate through each config element and extract the data
                # Example contents:
                # {'key': 'index', 'value': '2'}
                # {'key': 'printer_model_id', 'value': 'C12'}
                # {'key': 'nozzle_diameters', 'value': '0.4'}
                # {'key': 'timelapse_type', 'value': '0'}
                # {'key': 'prediction', 'value': '5935'}
                # {'key': 'weight', 'value': '20.91'}
                # {'key': 'outside', 'value': 'false'}
                # {'key': 'support_used', 'value': 'false'}
                # {'key': 'label_object_enabled', 'value': 'true'}
                # {'identify_id': '123', 'name': 'ModelObjectOne.stl', 'skipped': 'false'}
                # {'identify_id': '394', 'name': 'ModelObjectTwo.stl', 'skipped': 'false'}
                # {'id': '1', 'tray_info_idx': 'GFA01', 'type': 'PLA', 'color': '#000000', 'used_m': '5.45', 'used_g': '17.32'}
                # {'id': '2', 'tray_info_idx': 'GFA01', 'type': 'PLA', 'color': '#8D8C8F', 'used_m': '0.84', 'used_g': '2.66'}
                # {'id': '3', 'tray_info_idx': 'GFA01', 'type': 'PLA', 'color': '#FFFFFF', 'used_m': '0.29', 'used_g': '0.93'}
                
                # Start a total print length count to be compiled from each filament
                print_length = 0
                plate_number = None
                _printable_objects = {}
                filament_count = len(self.ams_mapping)
                plate_filament_count = len(plate.findall('filament'))

                # Reset filament data
                self._ams_print_weights = [0.0] * AMS_HT_UNIT_END # TODO: Convert to a dict in the future?
                self._ams_print_lengths = [0.0] * AMS_HT_UNIT_END # TODO: Convert to a dict in the future?

                for metadata in plate:
                    if (metadata.get('key') == 'index'):
                        # Index is the plate number being printed
                        plate_number = metadata.get('value')
                        LOGGER.debug(f"Plate: {plate_number}")
                        
                        # MQTT is authoritative for the plate that is actively printing.
                        # A printer can retain/reuse a 3mf whose slice_info points at a
                        # different plate, which otherwise makes the cover image stale.
                        active_plate_number = str(self.plate_idx) if self.plate_idx else plate_number
                        cover_entry_name = f"Metadata/plate_{active_plate_number}.png"
                        self._client._device.cover_image.set_image(archive.read(cover_entry_name))
                        LOGGER.debug(f"Cover image: {cover_entry_name}")

                        # Save the cover image to the cache
                        try:
                            # Save the cover image directly to the cache
                            cover_filename = os.path.splitext(os.path.basename(model_file_path))[0] + '.png'
                            cover_path = os.path.join(model_dir, cover_filename)
                            with archive.open(cover_entry_name) as cover_entry, open(cover_path, "wb") as target_path:
                                shutil.copyfileobj(cover_entry, target_path)
                            LOGGER.debug(f"Cover image saved to: {cover_path}")
                        except Exception as e:
                            LOGGER.error(f"Failed to save cover image: {e}")

                        try:
                            # Save the gcode file to the cache
                            gcode_filename = os.path.splitext(os.path.basename(model_file_path))[0] + '.gcode'
                            gcode_path = os.path.join(model_dir, gcode_filename)
                            with archive.open(f"Metadata/plate_{plate_number}.gcode") as gcode_entry, open(gcode_path, "wb") as target_path:
                                shutil.copyfileobj(gcode_entry, target_path)
                                self.gcode_file_downloaded = gcode_filename
                        except Exception as e:
                            self.gcode_file_downloaded = "ERROR"
                            LOGGER.error(f"Error while extracting gcode zip entry to target path. {repr(e)}")
                        
                        # And extract the plate type from the plate json.
                        self.print_bed_type = json.loads(archive.read(f"Metadata/plate_{plate_number}.json")).get('bed_type')
                    elif (metadata.get('key') == 'weight'):
                        LOGGER.debug(f"Weight: {metadata.get('value')}")
                        try:
                            # The XML attribute is a string; print_weight is a float everywhere else.
                            self.print_weight = float(metadata.get('value'))
                        except (TypeError, ValueError) as e:
                            LOGGER.error(f"Failed to parse print weight: {e}")
                    elif (metadata.get('key') == 'prediction'):
                        # Estimated print length in seconds
                        LOGGER.debug(f"Print time: {metadata.get('value')}s")
                    elif (metadata.tag == 'object'):
                        # Get the list of printable objects present on the plate before slicing.
                        # This includes hidden objects which need to be filtered out later.
                        if metadata.get('skipped') == f"false":
                            _printable_objects[metadata.get('identify_id')] = metadata.get('name')
                    elif (metadata.tag == 'filament'):
                        try:
                            # Filament used for the current print job. The plate info contains filaments
                            # identified in the order they appear in the slicer. These IDs must be
                            # mapped to the AMS tray mappings provided by MQTT print.ams_mapping

                            # Zero-index the filament ID
                            filament_index = int(metadata.get('id')) - 1
                            log_label = f"External spool"
                            
                            # Filament count should be greater than the zero-indexed filament ID
                            if filament_count > filament_index:
                                ams_index = self.ams_mapping[filament_index]
                                ams_name = ams_slot_name(ams_index)
                                if ams_name is not None:
                                    # We add the filament as you can map multiple slicer filaments to the same physical filament.
                                    self._ams_print_weights[ams_index] += float(metadata.get('used_g'))
                                    self._ams_print_lengths[ams_index] += float(metadata.get('used_m'))
                                    log_label = ams_name
                                else:
                                    LOGGER.debug(f"ams_mapping: {self.ams_mapping}")
                            elif plate_filament_count > 0:
                                # Multi filament print but the AMS mapping is unknown
                                # The data is only sent in the mqtt payload once and isn't part of the 'full' data so the integration must be
                                # live and listening to capture it.
                                LOGGER.debug(f"filament_index: {filament_index}")
                                log_label = f"AMS Tray unknown"
                            else:
                                LOGGER.debug(f"plate_filament_count: {plate_filament_count}")

                            LOGGER.debug(f"{log_label}: {metadata.get('used_m')}m | {metadata.get('used_g')}g")

                            # Increase the total print length
                            print_length += float(metadata.get('used_m'))
                        except Exception as e:
                            LOGGER.error(f"Failed to parse filament data: {e}")
                
                self.print_length = print_length

                if plate_number is not None:
                    try:
                        image = archive.read(f"Metadata/pick_{plate_number}.png")
                        self._client._device.pick_image.set_image(image)
                        # Process the pick image for objects
                        pick_image = Image.open(archive.open(f"Metadata/pick_{plate_number}.png"))
                        identify_ids = self._identify_objects_in_pick_image(image=pick_image)
                        
                        # Filter the printable objects from slice_info.config, removing
                        # any that weren't detected in the pick image
                        self._printable_objects = {k: _printable_objects[k] for k in identify_ids if k in _printable_objects}
                    except:
                        LOGGER.debug(f"Unable to load 'Metadata/pick_{plate_number}.png' from archive")

                # Save the slice_info.config file only if file cache is enabled
                try:
                    slice_info_bytes = archive.read('Metadata/slice_info.config')
                    # Save the slice_info.config in the same directory as the model file
                    slice_info_filename = os.path.splitext(os.path.basename(model_file_path))[0] + '.slice_info.config'
                    slice_info_path = os.path.join(model_dir, slice_info_filename)
                    with open(slice_info_path, "wb") as f:
                        f.write(slice_info_bytes)
                except Exception as e:
                    LOGGER.error(f"Failed to save slice_info.config: {e}")

            archive.close()

            self._client.callback("event_printer_data_update")
            result = True
        except Exception as e:
            LOGGER.error(f"Unexpected error parsing model data: {e}")
        
        self.prune_print_history_files()

        return result

    # The task list is of the following form with a 'hits' array with typical 20 entries.
    #
    # "total": 531,
    # "hits": [
    #     {
    #     "id": 35237965,
    #     "designId": 0,
    #     "designTitle": "",
    #     "instanceId": 0,
    #     "modelId": "REDACTED",
    #     "title": "REDACTED",
    #     "cover": "REDACTED",
    #     "status": 4,
    #     "feedbackStatus": 0,
    #     "startTime": "2023-12-21T19:02:16Z",
    #     "endTime": "2023-12-21T19:02:35Z",
    #     "weight": 34.62,
    #     "length": 1161,
    #     "costTime": 10346,
    #     "profileId": 35276233,
    #     "plateIndex": 1,
    #     "plateName": "",
    #     "deviceId": "REDACTED",
    #     "amsDetailMapping": [
    #         {
    #         "ams": 4,
    #         "sourceColor": "F4D976FF",
    #         "targetColor": "F4D976FF",
    #         "filamentId": "GFL99",
    #         "filamentType": "PLA",
    #         "targetFilamentType": "",
    #         "weight": 34.62
    #         }
    #     ],
    #     "mode": "cloud_file",
    #     "isPublicProfile": false,
    #     "isPrintable": true,
    #     "deviceModel": Printers.P1P,
    #     "deviceName": "Bambu P1P",
    #     "bedType": "textured_plate"
    #     },

    def _download_task_data_from_cloud(self):
        # Must have an auth token for this to be possible
        if self._client.bambu_cloud.auth_token == "":
            return

        self._task_data = self._client.bambu_cloud.get_latest_task_for_printer(self._client._serial)
        self._ams_print_weights = [0.0] * AMS_HT_UNIT_END # TODO: Convert to a dict in the future?
        self._ams_print_lengths = [0.0] * AMS_HT_UNIT_END # TODO: Convert to a dict in the future?
        if self._task_data is None:
            LOGGER.debug("No bambu cloud task data found for printer.")
            self._client._device.cover_image.set_image(None)
            self.print_weight = 0
            self.print_length = 0
            self.print_bed_type = "unknown"
            self.start_time = None
            self.end_time = None
        else:
            LOGGER.debug("Updating bambu cloud task data found for printer.")
            # For local prints with FTP available, the printer's 3mf is the
            # authoritative image source. Bambu Cloud's "latest task" can lag
            # behind the active print and return a stale cover.
            use_cloud_cover = not (self._print_type == "local" and self._client.ftp_enabled)
            url = self._task_data.get('cover', '')
            if use_cloud_cover and url != "":
                data = self._client.bambu_cloud.download(url)
                self._client._device.cover_image.set_image(data)

            self.print_length = self._task_data.get('length', self.print_length * 100) / 100
            self.print_bed_type = self._task_data.get('bedType', self.print_bed_type)
            self.print_weight = self._task_data.get('weight', self.print_weight)
            ams_print_data = self._task_data.get('amsDetailMapping', [])
            if self.print_weight != 0:
                for ams_data in ams_print_data:
                    index = ams_data['ams']
                    weight = ams_data['weight']
                    if ams_slot_name(index) is not None:
                        self._ams_print_weights[index] = weight
                        self._ams_print_lengths[index] = self.print_length * weight / self.print_weight
                    else:
                        # Common case is this is a machine without an AMS and we get index == 255 (not 254 as might be expected)
                        # And probably also a machine with an AMS but you did a print from the external spool.
                        # This could also hit if you have reconfigured your printer and removed an AMS.
                        LOGGER.debug(f"AMS tray {index} not found in _ams_print_weights")
                        LOGGER.debug(f"ams_print_data: {ams_print_data}")

            status = self._task_data['status']
            LOGGER.debug(f"CLOUD PRINT STATUS: {status}")
            if status == 4:
                # If we generate the start time (not X1), then rely more heavily on the cloud task data and
                # do so uniformly so we always have matched start/end times.
                # "startTime": "2023-12-21T19:02:16Z"
                
                cloud_time_str = self._task_data.get('startTime', "")
                LOGGER.debug(f"CLOUD START TIME1: {self.start_time}")
                if cloud_time_str != "":
                    cloud_dt = parser.parse(cloud_time_str)
                    if cloud_dt.tzinfo is None:
                        cloud_dt = cloud_dt.replace(tzinfo=tz.UTC)
                    # Convert everything to UTC-aware datetime
                    self.start_time = cloud_dt.astimezone(tz.UTC)
                    LOGGER.debug(f"CLOUD START TIME2: {self.start_time}")

                # "endTime": "2023-12-21T19:02:35Z"
                cloud_time_str = self._task_data.get('endTime', "")
                LOGGER.debug(f"CLOUD END TIME1: {self.end_time}")
                if cloud_time_str != "":
                    cloud_dt = parser.parse(cloud_time_str)
                    if cloud_dt.tzinfo is None:
                        cloud_dt = cloud_dt.replace(tzinfo=tz.UTC)
                    # Convert everything to UTC-aware datetime
                    self.end_time = cloud_dt.astimezone(tz.UTC)
                    LOGGER.debug(f"CLOUD END TIME2: {self.end_time}")

    def _identify_objects_in_pick_image(self, image: Image) -> set:
        LOGGER.debug(f"Processing the pick image for objects")
        # Open the pick image so we can detect objects present
        image_width, image_height = image.size
        
        seen_colors = set()
        seen_identify_ids = set()

        # Loop through every pixel and label the first occurrence of each unique color
        pixels = image.load()
        for y in range(image_height):
            for x in range(image_width):
                current_color = pixels[x, y]
                r, g, b, a = current_color

                # Skip this pixel if it's transparent or already identified
                if a == 0 or current_color in seen_colors:
                    continue

                # Convert the colour to the decimal representation of its hex value
                identify_id = int(f"0x{b:02X}{g:02X}{r:02X}", 16)
                seen_colors.add(current_color)
                seen_identify_ids.add(str(identify_id))
        
        object_count = len(seen_identify_ids)
        LOGGER.debug(f"Finished proccessing pick image, found {object_count} object{'s'[:object_count^1]}")
        return seen_identify_ids

    async def async_ftp_file_check(self, file_path: str, expected_size: int) -> bool:
        """Async check if a file exists on the printer via FTP and matches the expected size."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._sync_ftp_check, file_path, expected_size)

    def _sync_ftp_check(self, file_path: str, expected_size: int) -> bool:
        """Synchronous FTP check method to run in executor."""
        ftp = None
        try:
            # Use the connection helper from bambu_client
            ftp = self._client.ftp_connection()
            
            LOGGER.debug(f"FTP file check: Getting file size for {file_path}")
            # Get file size
            size = ftp.size(file_path)
            LOGGER.debug(f"FTP file check: File size is {size}, expected {expected_size}")
            
            return int(size) == expected_size
            
        except Exception as e:
            LOGGER.debug(f"FTP file check failed for {file_path}: {e}")
            return False
        finally:
            if ftp:
                try:
                    ftp.quit()
                except Exception:
                    pass

    async def async_ftp_upload_file(self, local_path: str, remote_path: str, progress_callback=None) -> bool:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._sync_ftp_upload, local_path, remote_path, progress_callback)

    def _sync_ftp_upload(self, local_path: str, remote_path: str, progress_callback=None) -> bool:
        try:
            # Before we upload, make sure the file is present in this printer's local cache directory
            relative_path = remote_path.lstrip('/')
            this_printer_cache_file_path = Path(self._client.cache_path) / "prints" / relative_path
            this_printer_cache_file_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(local_path, this_printer_cache_file_path)
            LOGGER.debug(f"Copied file to local cache: {this_printer_cache_file_path}")
        except Exception as e:
            LOGGER.error(f"Failed to copy file to local cache: {e}")

        ftp = None
        try:
            ftp = self._client.ftp_connection()

            # Ensure remote directory exists
            dirs = remote_path.strip('/').split('/')[:-1]
            current = ''
            for d in dirs:
                current += f'/{d}'
                try:
                    ftp.mkd(current)
                except Exception:
                    pass  # Directory may already exist which is fine

            LOGGER.debug(f"FTP upload: Starting file upload")
            file_size = os.path.getsize(local_path)
            filename = os.path.basename(local_path)
            total_sent = 0
            chunk_size = 8192

            def internal_progress_callback(data):
                nonlocal total_sent
                total_sent += len(data)
                if progress_callback:
                    progress_callback({
                        "serial": self._client._serial,
                        "filename": filename,
                        "bytes_sent": total_sent,
                        "total": file_size,
                    })

            with open(local_path, 'rb') as f:
                try:
                    ftp.storbinary_no_unwrap(f'STOR {remote_path}', f, blocksize=chunk_size, callback=internal_progress_callback)
                except Exception as e:
                    # Handle the benign 426 “Failure reading network stream” case
                    if "426" in str(e):
                        LOGGER.warning(f"Ignoring benign FTP 426 for {remote_path}: {e}")
                    else:
                        raise

            # Verify upload really succeeded by comparing file size
            remote_size = ftp.size(remote_path)
            if remote_size != file_size:
                LOGGER.error(f"Size mismatch after FTP upload ({remote_size} != expected {file_size})")
                raise ValueError(f"FTP upload verification failed: remote={remote_size}, local={file_size}")

            LOGGER.debug(f"FTP upload: Upload completed successfully")

            return True

        except Exception as e:
            LOGGER.debug(f"FTP upload failed for {local_path} to {remote_path}: {e}")
            return False
        finally:
            if ftp:
                try:
                    ftp.quit()
                except Exception:
                    pass

@dataclass
class Info:
    """Return all device related content"""

    # Device state
    serial: str
    device_type: str
    wifi_signal: int
    wifi_sent: datetime
    hw_ver: str
    sw_ver: str
    online: bool
    new_version_state: int
    mqtt_mode: str
    nozzle_diameters: dict[int, float|None]
    nozzle_types: dict[int, str|None]
    usage_hours: float
    extruder_filament_state: bool
    door_open: bool
    airduct_mode: int
        
    _ip_address: str
    _force_ip: bool

    def __init__(self, client):
        self._client = client

        self.serial = self._client._serial
        self.device_type = self._client._device_type
        self.wifi_signal = 0
        self.wifi_sent = datetime.now()
        self.hw_ver = "unknown"
        self.sw_ver = "unknown"
        self.online = False
        self.new_version_state = 0
        self.mqtt_mode = "local" if self._client._local_mqtt else "bambu_cloud"
        self.nozzle_diameters = {0: None, 1: None, 15: None}
        self.nozzle_types = {0: None, 1: None, 15: None}
        self.usage_hours = client._usage_hours
        self.extruder_filament_state = False
        self.door_open = False
        self.airduct_mode = 0
        self.airduct_modes_available = []
        self._ip_address = client.host
        self._force_ip = client.settings.get('force_ip', False)                

    @property
    def is_hybrid_mode_blocking(self) -> bool:
        if not self.mqtt_mode == "local":
            return False
        if not self._client._device.supports_feature(Features.HYBRID_MODE_BLOCKS_CONTROL):
            return False
        return self._client.bambu_cloud.bambu_connected

    def set_online(self, online):
        if self.online != online:
            self.online = online
            self._client.callback("event_printer_data_update")

    def info_update(self, data):

        # Example payload:
        # {
        # "info": {
        #     "command": "get_version",
        #     "sequence_id": "20004",
        #     "module": [
        #     {
        #         "name": "ota",
        #         "project_name": "C11",
        #         "sw_ver": "01.02.03.00",
        #         "hw_ver": "OTA",
        #         "sn": "..."
        #     },
        #     {
        #         "name": "esp32",
        #         "project_name": "C11",
        #         "sw_ver": "00.03.12.31",
        #         "hw_ver": "AP04",
        #         "sn": "..."
        #     },
        modules = data.get("module", [])
        old_device_type = self.device_type
        self.device_type = get_printer_type(modules, self.device_type)
        if old_device_type != self.device_type:
            LOGGER.debug(f"Device is {self.device_type}")
        self.hw_ver = get_hw_version(modules, self.hw_ver)
        self.sw_ver = get_sw_version(modules, self.sw_ver)
        self._client.callback("event_printer_info_update")

    def print_update(self, data) -> bool:
        old_data = f"{self.__dict__}"

        # Example payload:
        # {
        #     "print": {
        #         "gcode_start_time": "1681479206",
        #         "gcode_state": "IDLE",
        #         "mc_print_stage": "1",
        #         "mc_percent": 100,
        #         "mc_remaining_time": 0,
        #         "wifi_signal": "-53dBm",
        #         "print_type": "idle",
        #         "ipcam": {
        #             "ipcam_dev": "1",
        #             "ipcam_record": "enable"
        #             "resolution": "1080p",        # X1 only
        #             "timelapse": "disable"
        #         },
        #         "layer_num": 0,
        #         "total_layer_num": 0,

        # "print": {
        #   "net": {
        #     "conf": 16,
        #     "info": [
        #       {
        #         "ip": 1594493450,
        #         "mask": 16777215
        #       },
        #       {
        #         "ip": 0,
        #         "mask": 0
        #       }
        #     ]
        #   },

        if not self._force_ip:
            info = (data.get('net') or {}).get('info', [])
            for net in info:
                ip_int = net.get("ip", 0)
                if ip_int != 0:
                    prev_ip_address = self._ip_address
                    self._ip_address = get_ip_address_from_int(ip_int)
                    if self._ip_address != prev_ip_address:
                        # IP address was retrieved from the initial mqtt payload or has changed.
                        self._client.stop_camera()
                        self._client.start_camera()                    
                    break

        # Version data is provided differently for X1 and P1
        # P1P example:
        # "upgrade_state": {
        #   "sequence_id": 0,
        #   "progress": "",
        #   "status": "",
        #   "consistency_request": false,
        #   "dis_state": 1,
        #   "err_code": 0,
        #   "force_upgrade": false,
        #   "message": "",
        #   "module": "",
        #   "new_version_state": 1,
        #   "new_ver_list": [
        #     {
        #       "name": "ota",
        #       "cur_ver": "01.02.03.00",
        #       "new_ver": "01.03.00.00"
        #     },
        #     {
        #       "name": "ams/0",
        #       "cur_ver": "00.00.05.96",
        #       "new_ver": "00.00.06.32"
        #     }
        #   ]
        # },
        # X1 example:
        # "upgrade_state": {
        #     "ahb_new_version_number": "",
        #     "ams_new_version_number": "",
        #     "consistency_request": false,
        #     "dis_state": 0,
        #     "err_code": 0,
        #     "force_upgrade": false,
        #     "message": "",
        #     "module": "null",
        #     "new_version_state": 2,
        #     "ota_new_version_number": "",
        #     "progress": "0",
        #     "sequence_id": 0,
        #     "status": "IDLE"
        # },
        # The 'new_version_state' value is common to indicate a new upgrade is available.
        # Observed values so far are:
        # 1 - upgrade available
        # 2 - no upgrades available
        # And the P1P lists it's versions in new_ver_list as a structured set of data with old
        # and new versions provided for each component. While the X1 lists only the new version
        # in separate string properties.

        self.new_version_state = (data.get("upgrade_state") or {}).get("new_version_state", self.new_version_state)

        # Nozzle data is provided differently for dual-nozzle printers (at least)
        # New (H2D):
        #  "nozzle": {
        #    "info": [
        #      {"id": 0, "diameter": "0.4", "type": "HS01"},
        #      {"id": 1, "diameter": "0.4", "type": "HS01"}
        #    ]
        # },
        # Old (X1C v1.08.02.00 firmware):
        #  "nozzle": {
        #    "0": {
        #      "info": 8,
        #      "temp": 23
        #    },
        #    "info": 69
        #  }
        # Old:
        #   "nozzle_diameter": "0.4",
        #   "nozzle_type": "hardened_steel",
        nozzle_data = data.get("device", {}).get("nozzle", {}).get("info")
        if nozzle_data is not None and isinstance(nozzle_data, list):
            for entry in nozzle_data:
                if entry.get("id") in (0, 1):
                    self.nozzle_diameters[entry["id"]] = float(entry.get("diameter", 0))
                    self.nozzle_types[entry["id"]] = Info._nozzle_type_name(entry.get("type", ""))
        else:
            if "nozzle_diameter" in data:
                self.nozzle_diameters[0] = float(data["nozzle_diameter"])
            if "nozzle_type" in data:
                self.nozzle_types[0] = data["nozzle_type"]

        # Door status may be provided in two places depending on printer model.
        # X1 example:
        #   "home_flag": -1066934785,   # closed
        #   "home_flag": -1058546177,   # open
        # H2 example:
        #   "stat": "46258008",  # closed
        #   "stat": "46A58008",  # open
        if self.device_type in [Printers.X1, Printers.X1C, Printers.X1E]:
            if "home_flag" in data:
                self.door_open = (data["home_flag"] & Home_Flag_Values.DOOR_OPEN) != 0
        elif "stat" in data:
            stat_value = int(data["stat"], 16)
            self.door_open = (stat_value & Stat_Flag_Values.DOOR_OPEN) != 0


        # Airduct mode is provided under print/device/airduct
        airduct_data = data.get("device", {}).get("airduct", {})
        self.airduct_mode = airduct_data.get("modeCur", self.airduct_mode)

        mode_list = airduct_data.get("modeList")
        if mode_list is not None:
            self.airduct_modes_available = [
                AIRDUCT_MODES[entry["modeId"]]
                for entry in mode_list
                if entry.get("modeId") in AIRDUCT_MODES
            ]

        # Compute if there's a delta before we check the wifi_signal value.
        changed = (old_data != f"{self.__dict__}")

        # Now test the wifi signal to minimize how frequently we sent data upates to home assistant. We want
        # these changes to be done outside the delta test above so that we don't trigger an update every 2-3s
        # due the noise in this value on A1/P1 printers.
        old_wifi_signal = self.wifi_signal
        self.wifi_signal = int(data.get("wifi_signal", str(self.wifi_signal)).replace("dBm", ""))
        if (self.wifi_signal != old_wifi_signal) :
            if (datetime.now() - self.wifi_sent) > timedelta(seconds=60):
                # It's been long enough. We can send this one.
                self.wifi_sent = datetime.now()
                changed = True
        
        # "hw_switch_state": 1,
        self.extruder_filament_state = bool(data.get("hw_switch_state", self.extruder_filament_state))

        return changed

    @property
    def active_nozzle_diameter(self) -> float | None:
        return self.nozzle_diameters[self._client._device.extruder.active_nozzle_index]

    @property
    def active_nozzle_type(self) -> str | None:
        return self.nozzle_types[self._client._device.extruder.active_nozzle_index]

    @property
    def left_nozzle_diameter(self) -> float | None:
        return self.nozzle_diameters[1]

    @property
    def left_nozzle_type(self) -> str | None:
        return self.nozzle_types[1]

    @property
    def right_nozzle_diameter(self) -> float | None:
        return self.nozzle_diameters[0]

    @property
    def right_nozzle_type(self) -> str | None:
        return self.nozzle_types[0]

    @property
    def is_local_mqtt(self):
        return self._client._local_mqtt

    @property
    def has_bambu_cloud_connection(self) -> bool:
        return self._client.bambu_cloud.auth_token != ""
    
    @property
    def ip_address(self) -> str:
        return self._ip_address
    
    def set_prompt_sound(self, enable: bool):
        if enable:
            self._client.publish(PROMPT_SOUND_ENABLE)
        else:
            self._client.publish(PROMPT_SOUND_DISABLE)
            
    def set_airduct_mode(self, option: str):
        mode_id = next((k for k, v in AIRDUCT_MODES.items() if v == option), 0)
        command = AIRDUCT_SET_MODE_TEMPLATE.copy()
        command["print"] = {**command["print"], "modeId": mode_id}
        self._client.publish(command)
            

    def buzzer_silence(self):
        self._client.publish(BUZZER_SET_SILENT)

    def buzzer_fire_alarm(self):
        self._client.publish(BUZZER_SET_ALARM)

    def buzzer_attention_beep(self):
        self._client.publish(BUZZER_SET_SILENT) # need to reset first for it to work properly
        self._client.publish(BUZZER_SET_BEEPING)
       
    @staticmethod
    def _nozzle_type_name(nozzle_type_code: str) -> str:
        if str == "":
            return "unknown"

        # Second character indicates flow type (TPU high flow, high flow, standard)
        # There is only one TPU High-Flow nozzle offered as of this writing, and
        # Bambu Lab does not characterize the material.
        if nozzle_type_code[1] == "U":
            return "tpu_high_flow"

        if nozzle_type_code[1] in ("H", "E"):
            flow_prefix = "high_flow_"
        else:
            flow_prefix = ""

        # Last two digits indicate the material
        material_code = nozzle_type_code[2:4]
        _MATERIALS = {
            "00": "stainless_steel",
            "01": "hardened_steel",
            "05": "tungsten_carbide",
        }
        return flow_prefix + _MATERIALS.get(material_code, "unknown")


class Hotend:
    """Represents a single hotend in the Hotend Rack."""

    def __init__(self, hotend_id: int):
        self.id = hotend_id
        self.diameter: float = 0.0
        self.type_code: str = ""
        self.type_name: str = "unknown"
        self.serial: str = ""
        self.tm: int = 0
        # Total nozzle printing time in seconds (the printer's ``p_t`` field).
        self.print_time: int = 0
        self.wear: int = 0
        self.stat: int = 0
        self.color_m: str = "00000000"
        self.fila_id: str = ""
        self._active: bool = False

    @property
    def active(self) -> bool:
        return self._active

    @active.setter
    def active(self, value: bool):
        self._active = value

    @property
    def flow_type(self) -> str:
        if not self.type_code or len(self.type_code) < 2:
            return "Unknown"
        return "High Flow" if self.type_code[1] == "H" else "Standard"

    @property
    def status_name(self) -> str:
        status_bits = (self.stat >> 1) & 0x3
        return {0: "normal", 1: "abnormal", 2: "unknown"}.get(status_bits, "unknown")

    def print_update(self, data: dict) -> bool:
        old_data = f"{self.__dict__}"
        self.diameter = data.get("diameter", self.diameter)
        type_code = data.get("type", self.type_code)
        if type_code != self.type_code:
            self.type_code = type_code
            self.type_name = Info._nozzle_type_name(type_code) if type_code else "unknown"
        self.serial = data.get("sn", self.serial)
        self.tm = data.get("tm", self.tm)
        self.print_time = data.get("p_t", self.print_time)
        self.wear = data.get("wear", self.wear)
        self.stat = data.get("stat", self.stat)
        self.color_m = data.get("color_m", self.color_m)
        self.fila_id = data.get("fila_id", self.fila_id)
        return old_data != f"{self.__dict__}"


class HotendRack:
    """Manages the Hotend Rack (Vortek tool changer) system."""

    RACK_SLOT_IDS = range(16, 22)  # IDs 16-21

    def __init__(self, client):
        self._client = client
        self.hotends: dict[int, Hotend] = {}
        self.exist_bitmask: int = 0
        self.state: int = 0
        self.src_id: int = 0
        self.tar_id: int = 0
        self.holder_pos: int = 0
        self.holder_stat: int = 0

    def is_slot_occupied(self, slot_id: int) -> bool:
        """Check if a rack slot physically has a hotend."""
        return bool(self.exist_bitmask & (1 << slot_id))

    def _is_vortek_system(self, exist_bitmask: int, nozzle_info: list | None) -> bool:
        """Check if any hotend ID >= 16 exists in the bitmask or info array."""
        if exist_bitmask >= (1 << 16):
            return True
        if nozzle_info is not None and isinstance(nozzle_info, list):
            return any(entry.get("id", 0) >= 16 for entry in nozzle_info)
        return False

    def print_update(self, data) -> bool:
        changed = False

        nozzle_data = data.get("device", {}).get("nozzle", {})
        if not nozzle_data:
            return False

        exist = nozzle_data.get("exist", self.exist_bitmask)
        nozzle_info = nozzle_data.get("info")

        if not self._is_vortek_system(exist, nozzle_info):
            return False

        if self.exist_bitmask != exist:
            self.exist_bitmask = exist
            changed = True

        for attr, key in [("state", "state"), ("src_id", "src_id"), ("tar_id", "tar_id")]:
            value = nozzle_data.get(key)
            if value is not None and value != getattr(self, attr):
                setattr(self, attr, value)
                changed = True

        # Initialize rack slots that don't exist yet
        for slot_id in self.RACK_SLOT_IDS:
            if slot_id not in self.hotends: 
                self.hotends[slot_id] = Hotend(slot_id)

        # Update hotend data from info array
        if nozzle_info is not None and isinstance(nozzle_info, list):
            for entry in nozzle_info:
                nid = entry.get("id")
                if nid is not None and nid in self.hotends:
                    # Rack slot data (IDs 16-21)
                    if self.hotends[nid].print_update(entry):
                        changed = True
                elif nid is not None and nid < 16 and entry.get("type") and entry.get("sn", "N/A") != "N/A" and self.tar_id in self.hotends:
                    # Extruder nozzle with valid serial — update the mounted hotend's rack slot
                    if self.hotends[self.tar_id].print_update(entry):
                        changed = True

        # Holder data
        holder_data = data.get("device", {}).get("holder", {})
        if holder_data:
            for attr, key in [("holder_pos", "pos"), ("holder_stat", "stat")]:
                value = holder_data.get(key)
                if value is not None and value != getattr(self, attr):
                    setattr(self, attr, value)
                    changed = True

        return changed


@dataclass
class AMSInstance:
    """Return all AMS instance related info"""
    model: str
    tray: list[AMSTray]

    _active: bool = False
    serial: str = ""
    sw_version: str = ""
    hw_version: str = ""
    index: int = 0
    humidity_index: int = 0
    humidity: int = 0
    temperature: int = 0
    remaining_drying_time: int = 0
    drying_temperature: int = 0
    drying_duration: int = 0
    drying_filament: str = ""

    def __init__(self, client, model, index):
        self.model = model
        self.index = index
        if index >= 128:
            self.tray = [None]
            self.tray[0] = AMSTray(client)
        else:
            self.tray = [None] * 4
            self.tray[0] = AMSTray(client)
            self.tray[1] = AMSTray(client)
            self.tray[2] = AMSTray(client)
            self.tray[3] = AMSTray(client)

    @property
    def active(self):
        return self._active


@dataclass
class AMSList:
    """Return all AMS related info"""
    data: dict[int, AMSInstance]

    _nozzle_tray_index: dict
    _nozzle_ams_index: dict
    _first_initialization_done: bool = False

    def __init__(self, client):
        self._client = client
        self._nozzle_tray_index = { 0: 0, 1: 0, 15: 0}
        self._nozzle_ams_index = { 0: 0, 1: 0, 15: 0}
        self.data = {}

    @property
    def active_ams_index(self):
        active_nozzle = self._client._device.extruder.active_nozzle_index
        return self._nozzle_ams_index[active_nozzle]
    
    @property
    def active_tray_index(self):
        active_nozzle = self._client._device.extruder.active_nozzle_index
        return self._nozzle_tray_index[active_nozzle]
    
    @property
    def active_tray(self):
        if self.active_ams_index == 255:
            if self.active_tray_index == 255:
                return None
            else:
                return self._client._device.external_spool[0]
        elif self.active_ams_index == 254:
            if self.active_tray_index == 255:
                return None
            else:
                return self._client._device.external_spool[1]
        elif self.data[self.active_ams_index] is None:
            return None
        else:
            return self.data[self.active_ams_index].tray[self.active_tray_index]

    def info_update(self, data) -> bool:
        old_data = f"{self.__dict__}"

        # First determine if this the version info data or the json payload data. We use the version info to determine
        # what devices to add to humidity_index assistant and add all the sensors as entities. And then then json payload data
        # to populate the values for all those entities.

        # The module entries are of this form (P1/X1):
        # {
        #     "name": "ams/0",
        #     "project_name": "",
        #     "sw_ver": "00.00.05.96",
        #     "loader_ver": "00.00.00.00",
        #     "ota_ver": "00.00.00.00",
        #     "hw_ver": "AMS08",
        #     "sn": "<SERIAL>"
        # }
        # AMS Lite of the form:
        # {
        #   "name": "ams_f1/0",
        #   "project_name": "",
        #   "sw_ver": "00.00.07.89",
        #   "loader_ver": "00.00.00.00",
        #   "ota_ver": "00.00.00.00",
        #   "hw_ver": "AMS_F102",
        #   "sn": "**REDACTED**"
        # }

        data_changed = False
        module_list = data.get("module", [])
        for module in module_list:
            name = module["name"]
            index = -1
            model = ""
            if name.startswith("ams/"):
                model = "AMS"
                index = int(name[4:])
            elif name.startswith("ams_f1/"):
                model = "AMS Lite"
                index = int(name[7:])
            elif name.startswith("n3f/"):
                model = "AMS 2 Pro"
                index = int(name[4:])
            elif name.startswith("n3s/"):
                model = "AMS HT"
                index = int(name[4:])
            
            if index != -1:
                # Sometimes we get incomplete version data. We have to skip if that occurs since the serial number is
                # required as part of the home assistant device identity.
                if not module['sn'] == '':
                    # May get data before info so create entries if necessary
                    if index not in self.data:
                        data_changed = True
                        self.data[index] = AMSInstance(self._client, model, index)
                    if self.data[index].model != model:
                        data_changed = True
                        self.data[index].model = model
                    if self.data[index].serial != module['sn']:
                        data_changed = True
                        self.data[index].serial = module['sn']
                    if self.data[index].sw_version != module['sw_ver']:
                        data_changed = True
                        self.data[index].sw_version = module['sw_ver']
                    if self.data[index].hw_version != module['hw_ver']:
                        data_changed = True
                        self.data[index].hw_version = module['hw_ver']
            elif not self._first_initialization_done:
                self._first_initialization_done = True
                data_changed = True

        data_changed = data_changed or (old_data != f"{self.__dict__}")
        return data_changed

    def print_update(self, data) -> bool:
        old_data = f"{self.__dict__}"

        # AMS json payload is of the form:
        # "ams": {
        #     "ams": [
        #         {
        #             "id": "0",
        #             "humidity": "4",
        #             "temp": "0.0",
        #             "tray": [
        #                 {
        #                     "id": "0",
        #                     "remain": -1,
        #                     "k": 0.019999999552965164,        # P1P only
        #                     "n": 1.399999976158142,           # P1P only
        #                     "tag_uid": "0000000000000000",
        #                     "tray_id_name": "",
        #                     "tray_info_idx": "GFL99",
        #                     "tray_type": "PLA",
        #                     "tray_sub_brands": "",
        #                     "tray_color": "FFFF00FF",         # RRGGBBAA
        #                     "tray_weight": "0",
        #                     "tray_diameter": "0.00",
        #                     "drying_temp": "0",
        #                     "drying_time": "0",
        #                     "bed_temp_type": "0",
        #                     "bed_temp": "0",
        #                     "nozzle_temp_max": "240",
        #                     "nozzle_temp_min": "190",
        #                     "remain": 100,
        #                     "xcam_info": "000000000000000000000000",
        #                     "tray_uuid": "00000000000000000000000000000000"
        #                 },
        #                 {
        #                     "id": "1",
        #                     ...
        #                 },
        #                 {
        #                     "id": "2",
        #                     ...
        #                 },
        #                 {
        #                     "id": "3",
        #                     ...
        #                 }
        #             ]
        #         }
        #     ],
        #     "ams_exist_bits": "1",
        #     "tray_exist_bits": "f",
        #     "tray_is_bbl_bits": "f",
        #     "tray_now": "255",
        #     "tray_read_done_bits": "f",
        #     "tray_reading_bits": "0",
        #     "tray_tar": "255",
        #     "version": 3,
        #     "insert_flag": true,
        #     "power_on_flag": false
        # },

        ams_data = data.get("ams", {})

        extruder_data = data.get("device", {}).get("extruder", {}).get("info")
        if extruder_data is not None:
            for entry in extruder_data:
                if entry.get("id") in (0, 1):
                    if "snow" in entry:
                        tray_now = entry["snow"]
                        self._nozzle_ams_index[entry["id"]] = tray_now >> 8
                        self._nozzle_tray_index[entry["id"]] = tray_now & 0x3
        else:
            tray_now = ams_data.get('tray_now')
            if tray_now is not None:
                tray_now = int(tray_now)
                if tray_now == 255:
                    # In the legacy mqtt payloads 255 nothing active
                    self._nozzle_ams_index[0] = 255
                    self._nozzle_tray_index[0] = 255
                elif tray_now == 254:
                    # In the legacy mqtt payloads 254 = external spool active
                    self._nozzle_ams_index[0] = 255
                    self._nozzle_tray_index[0] = 0
                elif tray_now >= 80:
                    # AMS HT's are indices 128-135 (0x80-0x87)
                    self._nozzle_ams_index[0] = tray_now
                    self._nozzle_tray_index[0] = 0
                else:
                    # Otherwise we need to shift the index down by 2 to get the correct AMS index
                    self._nozzle_ams_index[0] = tray_now >> 2
                    self._nozzle_tray_index[0] = tray_now & 0x3

        if len(ams_data) != 0:
            ams_list = ams_data.get("ams", [])
            for ams in ams_list:
                index = int(ams['id'])
                # May get data before info so create entry if necessary
                if index not in self.data:
                    self.data[index] = AMSInstance(self._client, "Unknown", index)

                # Sometimes when the AMS is being powered on it may send bogus humidity and temperature values.
                # So ignore these values if they are out of a sensible range.

                humidity_index = int(ams['humidity'])
                if 1 <= humidity_index <= 5 and self.data[index].humidity_index != humidity_index:
                    self.data[index].humidity_index = humidity_index

                humidity = int(ams.get("humidity_raw", 0))
                if 1 <= humidity <= 100 and self.data[index].humidity != humidity:
                    self.data[index].humidity = humidity

                temperature = float(ams['temp'])
                if 0 <= temperature <= 100 and self.data[index].temperature != temperature:
                    self.data[index].temperature = temperature

                if self.data[index].remaining_drying_time != int(ams.get('dry_time', 0)):
                    self.data[index].remaining_drying_time = int(ams.get('dry_time', 0))

                dry_setting = ams.get('dry_setting', {})
                if dry_setting:
                    temp = dry_setting.get('dry_temperature', -1)
                    if self.data[index].drying_temperature != max(temp, 0):
                        self.data[index].drying_temperature = max(temp, 0)

                    duration = dry_setting.get('dry_duration', -1)
                    if self.data[index].drying_duration != max(duration, 0):
                        self.data[index].drying_duration = max(duration, 0)

                    filament = dry_setting.get('dry_filament', "")
                    if self.data[index].drying_filament != filament:
                        self.data[index].drying_filament = filament

                tray_list = ams['tray']
                for tray in tray_list:
                    tray_id = int(tray['id'])
                    self.data[index].tray[tray_id].print_update(tray)

        # Now that we've populated the AMS/Trays (if this is first time through), we must
        # loop over all the ams and trays to set active states correctly.
        for index in self.data:
            self.data[index]._active = (index == self.active_ams_index)
            for tray_id, tray in enumerate(self.data[index].tray):
                active_tray = (index == self.active_ams_index) and (self.active_tray_index == tray_id)
                tray.active = active_tray

        data_changed = (old_data != f"{self.__dict__}")
        return data_changed

@dataclass
class AMSTray:
    """Return all AMS tray related info"""
    empty: bool
    state: int
    idx: int
    name: str
    type: str
    sub_brands: str
    color: str
    nozzle_temp_min: int
    nozzle_temp_max: int
    _remain: int
    k: float
    tag_uid: str
    tray_uuid: str
    tray_weight: int
    _active: bool
    cols: list
    ctype: int
    dry_temp = int
    dry_time = int
    bed_temp = int

    def __init__(self, client):
        self._client = client
        self.empty = True
        self.state = 8
        self._state_reported = False
        self.idx = ""
        self.name = ""
        self.type = ""
        self.sub_brands = ""
        self.color = "00000000"  # RRGGBBAA
        self.nozzle_temp_min = 0
        self.nozzle_temp_max = 0
        self._remain = -1
        self.k = 0
        self.tag_uid = ""
        self.tray_uuid = ""
        self.tray_weight = 0
        self._active = False
        self.cols = []
        self.ctype = 0
        self.dry_temp = 0
        self.dry_time = 0
        self.bed_temp = 0

    @property
    def unknown(self) -> bool:
        """True when a spool is loaded but vendor/material/colour are not assigned."""
        return not self.empty and self.name == UNKNOWN_TRAY_LABEL

    @property
    def remain(self) -> int:
        return self._remain

    @property
    def active(self) -> bool:
        return self._active

    @active.setter
    def active(self, value: bool):
        self._active = value

    @property
    def remain_enabled(self) -> bool:
        return self._client._device.supports_feature(Features.AMS_FILAMENT_REMAINING) and self._client._device.home_flag.ams_calibrate_remaining

    def _reset_empty_slot(self) -> None:
        """Clear tray fields when no spool is loaded."""
        self.empty = True
        self.idx = ""
        self.name = "Empty"
        self.type = "Empty"
        self.sub_brands = ""
        self.color = "00000000"
        self.nozzle_temp_min = 0
        self.nozzle_temp_max = 0
        self._remain = -1
        self.tag_uid = ""
        self.tray_uuid = ""
        self.k = 0
        self.tray_weight = 0
        self.cols = []
        self.ctype = 0
        self.dry_temp = 0
        self.dry_time = 0
        self.bed_temp = 0

    def _resolve_tray_name(self, idx: str, tray_type: str) -> str:
        """Human-readable tray name; empty tray_type means unknown (?)."""
        if not tray_type or tray_type in ("", "Empty"):
            return UNKNOWN_TRAY_LABEL
        if idx:
            name = get_filament_name(idx, self._client.slicer_settings.custom_filaments)
            if name not in ("unknown", "Empty"):
                return name
        return tray_type

    def print_update(self, data) -> bool:
        old_data = f"{self.__dict__}"

        metadata_only = ('id' in data) and set(data.keys()).issubset({'id', 'state'})

        if 'state' in data:
            self._state_reported = True

        if metadata_only:
            self.state = int(data['state']) if 'state' in data else 0
        else:
            if 'state' in data:
                self.state = int(data['state'])
            self.idx = data.get('tray_info_idx', self.idx)
            self.type = data.get('tray_type', self.type)
            self.sub_brands = data.get('tray_sub_brands', self.sub_brands)
            self.color = data.get('tray_color', self.color)
            self.nozzle_temp_min = data.get('nozzle_temp_min', self.nozzle_temp_min)
            self.nozzle_temp_max = data.get('nozzle_temp_max', self.nozzle_temp_max)
            self._remain = data.get('remain', self._remain)
            self.tag_uid = data.get('tag_uid', self.tag_uid)
            self.tray_uuid = data.get('tray_uuid', self.tray_uuid)
            self.k = data.get('k', self.k)
            self.tray_weight = data.get('tray_weight', self.tray_weight)
            self.cols = data.get('cols', self.cols)
            self.ctype = data.get('ctype', self.ctype)
            self.dry_temp = data.get('tray_temp', self.dry_temp)
            self.dry_time = data.get('tray_time', self.dry_time)
            self.bed_temp = data.get('bed_temp', self.bed_temp)

        self._resolve_loaded_state(metadata_only)

        return (old_data != f"{self.__dict__}")

    def _has_filament_metadata(self) -> bool:
        """True when tray metadata indicates a spool is present.

        Fallback for firmware that never reports a per-tray ``state`` field:
        presence of a filament profile id or a real material type means a
        spool is loaded.
        """
        if self.idx:
            return True
        return bool(self.type) and self.type not in ("", "Empty")

    def _resolve_loaded_state(self, metadata_only: bool) -> None:
        """Determine empty/loaded status.

        Prefer the per-tray ``state`` bitfield when the printer reports one;
        otherwise fall back to filament metadata so printers whose firmware
        omits ``state`` still surface loaded spools instead of showing empty.
        """
        if self._state_reported:
            loaded = ams_tray_spool_loaded(self.state)
        else:
            loaded = self._has_filament_metadata()
        if loaded:
            self.empty = False
            name = self._resolve_tray_name(self.idx, self.type)
            self.name = name
            if name == UNKNOWN_TRAY_LABEL:
                if not self.type or self.type in ("", "Empty"):
                    self.type = UNKNOWN_TRAY_LABEL
                if not self.sub_brands:
                    self.sub_brands = UNKNOWN_TRAY_LABEL
        else:
            self._reset_empty_slot()


@dataclass
class ExternalSpool(AMSTray):
    """Return the virtual tray related info"""
    _index: int

    def __init__(self, client, index: int):
        self._physically_empty = True
        super().__init__(client)
        self._index = index

    @property
    def empty(self) -> bool:
        """True when no spool is mounted, or this external slot is not active."""
        if self._physically_empty:
            return True
        return not self.active

    @empty.setter
    def empty(self, value: bool) -> None:
        self._physically_empty = bool(value)

    @property
    def active(self) -> bool:
        if self._client._device.supports_feature(Features.AMS):
            active_ams_index = self._client._device.ams.active_ams_index
            active_tray_index = self._client._device.ams.active_tray_index
            if active_ams_index == (255 - self._index) and active_tray_index == 0:
                return True
        else:
            return True
        return False

    @property
    def remain(self) -> int:
        return -1

    @property
    def remain_enabled(self) -> bool:
        return False

    def _reset_empty_slot(self) -> None:
        """Clear tray fields when no external spool is mounted."""
        self._physically_empty = True
        self.idx = ""
        self.name = "Empty"
        self.type = "Empty"
        self.sub_brands = ""
        self.color = "00000000"
        self.nozzle_temp_min = 0
        self.nozzle_temp_max = 0
        self._remain = -1
        self.tag_uid = ""
        self.tray_uuid = ""
        self.k = 0
        self.tray_weight = 0
        self.cols = []
        self.ctype = 0
        self.dry_temp = 0
        self.dry_time = 0
        self.bed_temp = 0

    def _resolve_loaded_state(self, metadata_only: bool) -> None:
        """External spool: keep filament data; empty reflects active status."""
        if metadata_only:
            self._reset_empty_slot()
            return

        self._physically_empty = False
        name = self._resolve_tray_name(self.idx, self.type)
        self.name = name
        if name == UNKNOWN_TRAY_LABEL:
            if not self.type or self.type in ("", "Empty"):
                self.type = UNKNOWN_TRAY_LABEL
            if not self.sub_brands:
                self.sub_brands = UNKNOWN_TRAY_LABEL

    def print_update(self, data) -> bool:

        # P1P virtual tray example
        # "vt_tray": {
        #     "id": "254",
        #     "tag_uid": "0000000000000000",
        #     "tray_id_name": "",
        #     "tray_info_idx": "GFB99",
        #     "tray_type": "ABS",
        #     "tray_sub_brands": "",
        #     "tray_color": "000000FF",
        #     "tray_weight": "0",
        #     "tray_diameter": "0.00",
        #     "tray_temp": "0",
        #     "tray_time": "0",
        #     "bed_temp_type": "0",
        #     "bed_temp": "0",
        #     "nozzle_temp_max": "280",
        #     "nozzle_temp_min": "240",
        #     "remain": 100,
        #     "xcam_info": "000000000000000000000000",
        #     "tray_uuid": "00000000000000000000000000000000",
        #     "remain": 0,
        #     "k": 0.029999999329447746,
        #     "n": 1.399999976158142
        # },
        #
        # This is exact same data as the AMS exposes so we can just defer to the AMSTray object
        # to parse this json.

        # H2D virtual tray example
        # "vir_slot": [
        # {
        #     "bed_temp": "0",
        #     "bed_temp_type": "0",
        #     "cali_idx": -1,
        #     "cols": [
        #     "76D9F4FF"
        #     ],
        #     "ctype": 0,
        #     "drying_temp": "0",
        #     "drying_time": "0",
        #     "id": "254",
        #     "nozzle_temp_max": "240",
        #     "nozzle_temp_min": "190",
        #     "remain": 0,
        #     "tag_uid": "0000000000000000",
        #     "total_len": 330000,
        #     "tray_color": "76D9F4FF",
        #     "tray_diameter": "1.75",
        #     "tray_id_name": "",
        #     "tray_info_idx": "GFA01",
        #     "tray_sub_brands": "",
        #     "tray_type": "PLA",
        #     "tray_uuid": "00000000000000000000000000000000",
        #     "tray_weight": "0",
        #     "xcam_info": "000000000000000000000000"
        # },
        # {
        # ...
        #     "id": "254",

        received_virtual_tray_data = False

        if data.get("vir_slot") is not None:
            for vir_slot in data.get("vir_slot"):
                id = int(vir_slot.get("id"))
                if id == (255 - self._index):
                    tray_data = vir_slot
                    received_virtual_tray_data = super().print_update(tray_data)
        else:
            tray_data = data.get("vt_tray", {})
            if len(tray_data) != 0:
                received_virtual_tray_data = super().print_update(tray_data)

        return received_virtual_tray_data


@dataclass
class Speed:
    """Return speed profile information"""
    _id: int
    name: str
    modifier: int

    def __init__(self, client):
        self._client = client
        self._id = 2
        self.name = get_speed_name(2)
        self.modifier = 100

    def print_update(self, data) -> bool:
        old_data = f"{self.__dict__}"

        self._id = int(data.get("spd_lvl", self._id))
        self.name = get_speed_name(self._id)
        self.modifier = int(data.get("spd_mag", self.modifier))
        
        return (old_data != f"{self.__dict__}")

    def SetSpeed(self, option: str):
        for id, speed in SPEED_PROFILE.items():
            if option == speed:
                self._id = id
                self.name = speed
                command = copy.deepcopy(SPEED_PROFILE_TEMPLATE)
                command['print']['param'] = f"{id}"
                self._client.publish(command)
                self._client.callback("event_speed_update")


@dataclass
class StageAction:
    """Return Stage Action information"""
    _id: int
    _print_type: str
    description: str

    def __init__(self):
        self._id = 255
        self._print_type = ""
        self.description = get_current_stage(self._id)

    def print_update(self, data) -> bool:
        old_data = f"{self.__dict__}"

        self._print_type = data.get("print_type", self._print_type)
        if self._print_type.lower() not in PRINT_TYPE_OPTIONS:
            self._print_type = "unknown"

        # New way it is presented
        self._id = int((data.get("stage") or {}).get("_id", self._id))
        # Old way it's presented
        self._id = int(data.get("stg_cur", self._id))
        if (self._print_type == "idle") and (self._id == 0):
            # On boot the printer reports stg_cur == 0 incorrectly instead of 255. Attempt to correct for this.
            self._id = 255
        self.description = get_current_stage(self._id)

        return (old_data != f"{self.__dict__}")

@dataclass
class HMSList:
    """Return all HMS related info"""
    _errors: dict

    def __init__(self, client):
        self._client = client
        self._errors = {}
        self._errors["Count"] = 0
        self._hms_list = []
        self._device_type = None
        self._user_language = None
        
    def print_update(self, data) -> bool:
        # Example payload:
        # "hms": [
        #     {
        #         "attr": 50331904, # In hex this is 0300 0100
        #         "code": 65543     # In hex this is 0001 0007
        #     }
        # ],
        # So this is HMS_0300_0100_0001_0007:
        # https://wiki.bambulab.com/en/x1/troubleshooting/hmscode/0300_0100_0001_0007
        # 'The heatbed temperature is abnormal; the sensor may have an open circuit.'

        if 'hms' not in data.keys():
            return False
        
        hms_list = data.get('hms', [])
        device_type = self._client._device.info.device_type
        user_language = self._client.user_language
        if hms_list == self._hms_list and user_language == self._user_language and device_type == self._device_type:
            # No change
            return False

        LOGGER.debug(f"Parsing {hms_list=}")
        errors = {}

        index: int = 0
        for hms in hms_list:
            attr = int(hms['attr'])
            code = int(hms['code'])
            hms_notif = HMSNotification(
                device_type=device_type,
                user_language=user_language,
                attr=attr,
                code=code
                )
            if not hms_notif.hms_error:
                LOGGER.debug("Skipping HMS notification with code %s (no text).", hms_notif.hms_code)
                continue  # skip invalid entries

            index = index + 1
            errors[f"{index}-Code"] = f"HMS_{hms_notif.hms_code}"
            errors[f"{index}-Error"] = hms_notif.hms_error
            errors[f"{index}-Wiki"] = hms_notif.wiki_url
            errors[f"{index}-Severity"] = hms_notif.severity
            #LOGGER.debug(f"HMS error for '{hms_notif.module}' and severity '{hms_notif.severity}': HMS_{hms_notif.hms_code}")
            #errors[f"{index}-Module"] = hms_notif.module # commented out to avoid bloat with current structure

        errors["Count"] = index
        self._hms_list = hms_list
        self._user_language = user_language
        self._device_type = device_type

        if self._errors != errors:
            LOGGER.debug("Updating HMS error list.")
            self._errors = errors
            if self._errors["Count"] != 0:
                LOGGER.debug(f"HMS ERRORS: {errors}")
            self._client.callback("event_printer_error")
            return True
        
        return False
    
    @property
    def errors(self) -> dict:
        #LOGGER.debug(f"PROPERTYCALL: get_hms_errors")
        return self._errors
    
    @property
    def error_count(self) -> int:
        return self._errors["Count"]

@dataclass
class PrintError:
    """Return all print_error related info"""
    _error: dict

    def __init__(self, client):
        self._error = None
        self._client = client
        
    def print_update(self, data) -> bool:
        # Example payload:
        # "print_error": 117473286 
        # So this is 07008006 which we make more human readable to 0700-8006
        # https://e.bambulab.com/query.php?lang=en
        # 'Unable to feed filament into the extruder. This could be due to entangled filament or a stuck spool. If not, please check if the AMS PTFE tube is connected.'

        if 'print_error' in data.keys():
            errors = None
            code = data.get('print_error')
            if code != 0:
                code = f'0{int(code):x}'
                code = code[slice(0,4,1)] + "_" + code[slice(4,8,1)]
                code = code.upper()
                errors = {}
                errors[f"code"] = code
                error_text = get_print_error_text(code, self._client._device.info.device_type, self._client.user_language)
                errors[f"error"] = error_text
                if error_text == 'unknown':
                    # Suppress unknown errors as they get fired when there are no errors.
                    errors = None

            if self._error != errors:
                self._error = errors
                self._client.callback("event_print_error")

        # We send the error event directly so always return False for the general data event.
        return False
    
    @property
    def error(self) -> dict:
        return self._error
    
    @property
    def on(self) -> int:
        return self._error is not None


@dataclass
class HMSNotification:
    """Return an HMS object and all associated details"""
    attr: int
    code: int

    def __init__(self, device_type: Printers | str, user_language: str, attr: int, code: int):
        self._device_type = device_type
        self._user_language = user_language
        self.attr = attr
        self.code = code

    @property
    def severity(self):
        return get_HMS_severity(self.code)

    @property
    def module(self):
        return get_HMS_module(self.attr)

    @property
    def hms_code(self):
        if self.attr > 0 and self.code > 0:
            return f'{int(self.attr / 0x10000):0>4X}_{self.attr & 0xFFFF:0>4X}_{int(self.code / 0x10000):0>4X}_{self.code & 0xFFFF:0>4X}' # 0300_0100_0001_0007
        return ""
    
    @property
    def hms_error(self) -> str:
        error_text = get_HMS_error_text(self.hms_code, self._device_type, self._user_language)
        return error_text

    @property
    def wiki_url(self):
        if self.attr > 0 and self.code > 0:
            return get_wiki_url_for_hms_error(self.hms_code, self._device_type)
        return ""


@dataclass
class ChamberImage:
    """Returns the latest jpeg data from the P1P camera"""
    def __init__(self, client):
        self._client = client
        self._bytes = bytearray()
        self._image_last_updated = None

    def set_image(self, bytes):
        self._bytes = bytes
        self._image_last_updated = datetime.now()
        self._client.callback("event_printer_chamber_image_update")

    def get_image(self) -> bytearray:
        return self._bytes.copy()
    
    def get_last_update_time(self) -> datetime:
        return self._image_last_updated

    
@dataclass
class CoverImage:
    """Returns the cover image from the Bambu API or FTP"""

    def __init__(self, client):
        self._client = client
        self._bytes = bytearray()
        self._image_last_updated = None
        self._client.callback("event_printer_cover_image_update")

    def set_image(self, bytes):
        self._bytes = bytes
        self._image_last_updated = datetime.now()
        self._client.callback("event_printer_cover_image_update")
    
    def get_image(self) -> bytearray:
        return self._bytes

    def get_last_update_time(self) -> datetime:
        return self._image_last_updated

    
@dataclass
class PickImage:
    """Returns the object pick image from the FTP"""

    def __init__(self, client):
        self._client = client
        self._bytes = bytearray()
        self._image_last_updated = datetime.now()
        self._client.callback("event_printer_pick_image_update")

    def set_image(self, bytes):
        self._bytes = bytes
        self._image_last_updated = datetime.now()
        self._client.callback("event_printer_pick_image_update")
    
    def get_image(self) -> bytearray:
        return self._bytes

    def get_last_update_time(self) -> datetime:
        return self._image_last_updated


@dataclass
class HomeFlag:
    """Contains parsed _values from the homeflag sensor"""
    _value: int
    _sw_ver: str
    _device_type: str 
    _fired_missing_sdcard_event: bool

    def __init__(self, client):
        self._value = 0
        self._client = client
        self._sw_ver = ""
        self._device_type = ""
        self._fired_missing_sdcard_event = False

    def info_update(self, data):
        modules = data.get("module", [])
        self._device_type = get_printer_type(modules, self._device_type)
        self._sw_ver = get_sw_version(modules, self._sw_ver)

    def print_update(self, data: dict) -> bool:
        old_data = f"{self.__dict__}"
        self._value = int(data.get("home_flag", str(self._value)))
        if self.sdcard_status == "missing":
            if not self._fired_missing_sdcard_event:
                self._fired_missing_sdcard_event = True
                self._client.callback("event_printer_missing_sdcard")
        else:
            self._fired_missing_sdcard_event = False
        return (old_data != f"{self.__dict__}")

    @property
    def sdcard_status(self) -> str:
        if (self._value & Home_Flag_Values.SD_CARD_ABNORMAL) != 0:
            return "abnormal"
        if (self._value & Home_Flag_Values.SD_CARD_PRESENT) != 0:
            return "normal"
        return "missing"

    @property
    def x_axis_homed(self) -> bool:
        return (self._value & Home_Flag_Values.X_AXIS) != 0
    
    @property
    def y_axis_homed(self) -> bool:
        return (self._value & Home_Flag_Values.Y_AXIS) != 0

    @property
    def z_axis_homed(self) -> bool:
        return (self._value & Home_Flag_Values.Z_AXIS) != 0

    @property
    def homed(self) -> bool:
        return self.x_axis_homed and self.y_axis_homed and self.z_axis_homed

    @property
    def is_220V(self) -> bool:
        return (self._value & Home_Flag_Values.VOLTAGE220) != 0

    @property
    def xcam_autorecovery_steploss(self) -> bool:
        return (self._value & Home_Flag_Values.XCAM_AUTO_RECOVERY_STEP_LOSS) != 0

    @property
    def camera_recording(self) -> bool:
        return (self._value & Home_Flag_Values.CAMERA_RECORDING) != 0

    @property
    def ams_calibrate_remaining(self) -> bool:
        return (self._value & Home_Flag_Values.AMS_CALIBRATE_REMAINING) != 0

    @property
    def ams_auto_switch_filament(self) -> bool:
        return (self._value & Home_Flag_Values.AMS_AUTO_SWITCH) != 0

    @property
    def wired_network_connection(self):
        return (self._value & Home_Flag_Values.WIRED_NETWORK) != 0

    @property
    def xcam_prompt_sound(self) -> bool:
        return (self._value & Home_Flag_Values.XCAM_ALLOW_PROMPT_SOUND) != 0

    @property
    def supports_motor_noise_calibration(self) -> bool:
        return (self._value & Home_Flag_Values.SUPPORTS_MOTOR_CALIBRATION) != 0
    
    @property
    def p1s_upgrade_supported(self) -> bool:
        return (self._value & Home_Flag_Values.SUPPORTED_PLUS) !=  0
    
    @property
    def p1s_upgrade_installed(self) -> bool:
        return (self._value & Home_Flag_Values.INSTALLED_PLUS) !=  0


@dataclass
class PrintFun:
    """Contains parsed _values from the print->fun sensor"""
    _value: str
    _int_value: int
    _encryption_enabled: bool
    _fired_encryption_enabled_event: bool
    
    def __init__(self, client):
        self._value = ""
        self._client = client
        self._encryption_enabled = False
        self._int_value: int = 0
        self._fired_encryption_enabled_event = False

    def print_update(self, data: dict) -> bool:
        old_data = f"{self.__dict__}"
        self._value = data.get("fun", str(self._value))
        self._int_value = int(self._value, 16) if self._value else 0
        self._encryption_enabled = (self._int_value & Print_Fun_Values.MQTT_SIGNATURE_REQUIRED) != 0
        if self._encryption_enabled:
            if not self._fired_encryption_enabled_event:
                self._fired_encryption_enabled_event = True
                self._client.callback("event_printer_mqtt_encryption_enabled")

        return (old_data != f"{self.__dict__}")

    @property
    def mqtt_signature_required(self) -> bool:
        return self._encryption_enabled
    

@dataclass
class FilamentInfo:
    name: str
    filament_vendor: str
    filament_type: str
    filament_density: float
    nozzle_temperature: int
    nozzle_temperature_range_high: int
    nozzle_temperature_range_low: int

# Example custom filament;
# {
#   "setting_id": "PFUS9be9e18f81828a",
#   "version": "1.9.0.2",
#   "update_time": "2024-03-30 11:54:22",
#   "name": "ELEGOO PLA Black @Bambu Lab X1 Carbon 0.6 nozzle",
#   "nickname": null,
#   "base_id": null,
#   "filament_vendor": "ELEGOO",
#   "filament_id": "P9816594",
#   "filament_type": "PLA",
#   "filament_is_support": false,
#   "nozzle_temperature": [
#     190,
#     240
#   ],
#   "nozzle_hrc": 3
# },
      
class SlicerSettings:
    custom_filaments: dict = field(default_factory=dict)

    def __init__(self, client):
        self._client = client
        self.custom_filaments = {}

    @property
    def filaments(self):
        return self.custom_filaments

    def _load_custom_filaments(self, slicer_settings: dict):
        filaments = slicer_settings.get("filament")
        if filaments is not None:
            private_filaments = filaments.get("private", {})
            for filament in private_filaments:
                if filament.get("filament_id", "") != "":
                    name = filament["name"]
                    if " @" in name:
                        name = name[:name.index(" @")]
                    id = filament["filament_id"]
                    self.custom_filaments[id] = FilamentInfo(
                        name=name,
                        filament_vendor=filament["filament_vendor"],
                        filament_type=filament["filament_type"],
                        filament_density=0,
                        nozzle_temperature=0,
                        nozzle_temperature_range_high=filament["nozzle_temperature"][1],
                        nozzle_temperature_range_low=filament["nozzle_temperature"][0]
                    )
            LOGGER.debug(f"Got {len(self.custom_filaments)} custom filaments.")
        else:
            LOGGER.debug(f"Received no filament data: {filaments}")

    def update(self):
        self.custom_filaments = {}
        if self._client.bambu_cloud.auth_token != "":
            LOGGER.debug(f"Loading slicer settings for {self._client._device.info.device_type} / {self._client._serial}")
            slicer_settings = self._client.bambu_cloud.get_slicer_settings()
            if slicer_settings is None:
                LOGGER.debug(f"Failed to get slicer settings for {self._client._device.info.device_type} / {self._client._serial}")
                self._client.callback("event_printer_bambu_authentication_failed")
            else:
                self._load_custom_filaments(slicer_settings)

class ExtruderTool:
    """Contains parsed _values from the ext_tool sensor"""
    state: str

    def __init__(self, client):
        self._client = client
        self.state = None

    def print_update (self, data):
        # Handle ext_tool update
        old_data = f"{self.__dict__}"

        if "device" in data and "ext_tool" in data["device"]:
            ext_tool = data["device"]["ext_tool"]
            mount = ext_tool.get("mount")
            tool_type = ext_tool.get("type")
            prev_state = self.state
            if mount == 0:
                self.state = "none"
            elif mount == 1 and tool_type == "LB00":
                self.state = "laser10"
            elif mount == 1 and tool_type == "LB01":
                self.state = "laser40"
            elif mount == 1 and tool_type == "CP00":
                self.state = "cutter"
            elif mount == 1 and tool_type:
                self.state = None
        
        return (old_data != f"{self.__dict__}")
    
class Extruder:
    _active_nozzle_index: int

    def __init__(self, client):
        self._client = client
        self._active_nozzle_index = 0

    def print_update (self, data):
        # Handle ext_tool update
        old_data = f"{self.__dict__}"

        extruder_state = data.get("device", {}).get("extruder", {}).get("state")
        if extruder_state is not None:
            self._active_nozzle_index = (extruder_state >> 4) & 0xF
                        
        return (old_data != f"{self.__dict__}")

    @property
    def active_nozzle_index(self):
        return self._active_nozzle_index
