"""Image platform."""
from __future__ import annotations

from datetime import datetime

from homeassistant.components.image import ImageEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.dispatcher import async_dispatcher_connect
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN, LOGGER, Options
from .coordinator import BambuDataUpdateCoordinator
from .models import BambuLabEntity
from .definitions import BambuLabSensorEntityDescription
from .pybambu.const import Features

CHAMBER_IMAGE_SENSOR = BambuLabSensorEntityDescription(
        key="p1p_camera",
        translation_key="p1p_camera",
        value_fn=lambda self: self.coordinator.get_model().get_camera_image(),
        exists_fn=lambda coordinator: coordinator.get_model().supports_feature(Features.CAMERA_IMAGE) and
                                      coordinator.get_option_enabled(Options.CAMERA) and
                                      coordinator.get_option_enabled(Options.IMAGECAMERA)
    )

COVER_IMAGE_SENSOR = BambuLabSensorEntityDescription(
        key="cover_image",
        translation_key="cover_image",
        value_fn=lambda self: self.coordinator.get_model().print_job.get_cover_image()
    )

PICK_IMAGE_SENSOR = BambuLabSensorEntityDescription(
        key="pick_image",
        translation_key="pick_image",
        value_fn=lambda self: self.coordinator.get_model().print_job.get_pick_image()
    )


async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up the Everything but the Kitchen Sink config entry."""

    coordinator: BambuDataUpdateCoordinator = hass.data[DOMAIN][config_entry.entry_id]
    if not coordinator.get_model().has_full_printer_data:
        return

    LOGGER.debug("IMAGE::async_setup_entry")

    cover_image = CoverImage(hass, coordinator, COVER_IMAGE_SENSOR)
    pick_image = PickImage(hass, coordinator, PICK_IMAGE_SENSOR)
    async_add_entities([cover_image, pick_image])

    if CHAMBER_IMAGE_SENSOR.exists_fn(coordinator):
        chamber_image = ChamberImage(hass, coordinator, CHAMBER_IMAGE_SENSOR)
        async_add_entities([chamber_image])


class DispatchedImageEntity:
    """Mixin that refreshes the entity from a targeted dispatcher signal.

    Image updates are pushed per-entity by the coordinator instead of through a full
    coordinator refresh (see coordinator.image_update_signal)."""

    IMAGE_SIGNAL_TYPE: str

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        self.async_on_remove(
            async_dispatcher_connect(
                self.hass,
                self.coordinator.image_update_signal(self.IMAGE_SIGNAL_TYPE),
                self._handle_image_update,
            )
        )

    @callback
    def _handle_image_update(self) -> None:
        self.async_write_ha_state()


class CoverImage(DispatchedImageEntity, ImageEntity, BambuLabEntity):
    """Representation of an image entity."""

    IMAGE_SIGNAL_TYPE = "cover"

    def __init__(
        self,
        hass: HomeAssistant,
        coordinator: BambuDataUpdateCoordinator,
        description: BambuLabSensorEntityDescription
    ) -> None:
        """Initialize the image entity."""
        super().__init__(hass=hass)
        super(BambuLabEntity, self).__init__(coordinator=coordinator)
        self._attr_content_type = "image/jpeg"
        self._image_filename = None
        self.entity_description = description
        printer = self.coordinator.get_model().info
        self._attr_unique_id = f"{printer.serial}_{description.key}"

    def image(self) -> bytes | None:
        """Return bytes of image."""
        return self.coordinator.get_model().cover_image.get_image()

    @property
    def image_last_updated(self) -> datetime | None:
        """The time when the image was last updated."""
        return self.coordinator.get_model().cover_image.get_last_update_time()

    @property
    def available(self) -> bool:
        return self.coordinator.get_model().cover_image.get_last_update_time() != None
    
class ChamberImage(DispatchedImageEntity, ImageEntity, BambuLabEntity):
    """Representation of an image entity."""

    IMAGE_SIGNAL_TYPE = "chamber"

    def __init__(
        self,
        hass: HomeAssistant,
        coordinator: BambuDataUpdateCoordinator,
        description: BambuLabSensorEntityDescription
    ) -> None:
        """Initialize the image entity."""
        super().__init__(hass=hass)
        super(BambuLabEntity, self).__init__(coordinator=coordinator)
        self._attr_content_type = "image/jpeg"
        self._image_filename = None
        self.entity_description = description
        printer = self.coordinator.get_model().info
        self._attr_unique_id = f"{printer.serial}_{description.key}"

    def image(self) -> bytes | None:
        """Return bytes of image."""
        return self.coordinator.get_model().chamber_image.get_image()
    
    @property
    def image_last_updated(self) -> datetime | None:
        """The time when the image was last updated."""
        return self.coordinator.get_model().chamber_image.get_last_update_time()


class PickImage(DispatchedImageEntity, ImageEntity, BambuLabEntity):
    """Representation of an object pick image entity."""

    IMAGE_SIGNAL_TYPE = "pick"

    def __init__(
        self,
        hass: HomeAssistant,
        coordinator: BambuDataUpdateCoordinator,
        description: BambuLabSensorEntityDescription
    ) -> None:
        """Initialize the image entity."""
        super().__init__(hass=hass)
        super(BambuLabEntity, self).__init__(coordinator=coordinator)
        self._attr_content_type = "image/png"
        self._image_filename = None
        self.entity_description = description
        printer = self.coordinator.get_model().info
        self._attr_unique_id = f"{printer.serial}_{description.key}"

    def image(self) -> bytes | None:
        """Return bytes of image."""
        return self.coordinator.get_model().pick_image.get_image()

    @property
    def image_last_updated(self) -> datetime | None:
        """The time when the image was last updated."""
        return self.coordinator.get_model().pick_image.get_last_update_time()

    @property
    def available(self) -> bool:
        return self.image() is not None
